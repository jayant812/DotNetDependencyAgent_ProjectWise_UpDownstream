import React from 'react'
import ReactDOM from 'react-dom/client'
import { HashRouter, Routes, Route } from "react-router-dom";
import { initializeIcons } from "@fluentui/react";
 
import './index.css'
 
import Layout from "./pages/layout/Layout";
import OneShot from "./pages/oneshot/OneShot";
import Chat from "./pages/chat/Chat";
import FileUploader from './pages/uploadfile/FileUploader';
import NoPage from "./pages/NoPage";
import { getUserId, newChat } from "./api"
 
initializeIcons();
 
// Set current user id
getUserId();
 
export default function App() {
  return (
      <HashRouter>
          <Routes>
              <Route path="/" element={<Layout />}>
                  <Route index element={<Chat />} />
                  <Route path="qa" element={<OneShot />} />
                  <Route path="ul" element={<FileUploader />} />
                  <Route path="*" element={<NoPage />} />
              </Route>
          </Routes>
      </HashRouter>
  );
}
 
 
ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)