using DotNetDependencyAgent;
using Xunit;

namespace DotNetDependencyAgent.Tests;

public sealed class ChangeImpactAnalyzerTests
{
    [Fact]
    public void Analyze_ExactFunction_ReturnsTarget()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "Workflow.Process()");

        Assert.Single(result.MatchedFunctions);
        Assert.Contains("Workflow.Process()", result.MatchedFunctions[0]);
    }

    [Fact]
    public void Analyze_FunctionNameWithoutType_MatchesFunction()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "Process");

        Assert.Single(result.MatchedFunctions);
        Assert.Contains("Workflow.Process()", result.MatchedFunctions[0]);
    }

    [Fact]
    public void Analyze_ReturnsDirectCaller()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "Workflow.Process()");

        Assert.Contains(result.DirectCallers, x => x.Contains("Workflow.Start()"));
    }

    [Fact]
    public void Analyze_ReturnsMultipleDirectCallees()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "Workflow.Process()");

        Assert.Contains(result.DirectCallees, x => x.Contains("Workflow.Validate()"));
        Assert.Contains(result.DirectCallees, x => x.Contains("Workflow.Save()"));
    }

    [Fact]
    public void Analyze_FindsTransitiveCallers()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "Workflow.Save()");

        Assert.Contains(result.DirectCallers, x => x.Contains("Workflow.Process()"));
        Assert.Contains(result.TransitiveCallers, x => x.Contains("Workflow.Start()"));
    }

    [Fact]
    public void Analyze_FindsTransitiveDownstreamFunctions()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "Workflow.Start()");

        Assert.Contains(result.DirectCallees, x => x.Contains("Workflow.Process()"));
        Assert.Contains(result.TransitiveCallees, x => x.Contains("Workflow.Validate()"));
        Assert.Contains(result.TransitiveCallees, x => x.Contains("Workflow.Save()"));
    }

    [Fact]
    public void Analyze_FileTarget_MatchesFunctionsInFile()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "Workflow.cs");

        Assert.Equal(4, result.MatchedFunctions.Count);
    }

    [Fact]
    public void Analyze_ProjectTarget_ReportsImpactedProject()
    {
        var report = CreateReport();
        report.ProjectDependencies.Add(new ProjectDependencyInfo
        {
            Project = "ConsumerProject",
            RelatedProject = "ProjectA",
            Direction = "Downstream",
            Relationship = "ProjectReference",
            Confidence = "Confirmed"
        });
        report.ProjectDependencies.Add(new ProjectDependencyInfo
        {
            Project = "ProjectA",
            RelatedProject = "ConsumerProject",
            Direction = "Upstream",
            Relationship = "Reverse ProjectReference",
            Confidence = "Confirmed"
        });

        var result = new ChangeImpactAnalyzer().Analyze(report, "ProjectA");

        Assert.Contains("ConsumerProject", result.ImpactedProjects);
    }

    [Fact]
    public void Analyze_CapturesExternalDependencyForTargetFunction()
    {
        var report = CreateReport();
        report.Dependencies.Add(new DependencyUsage
        {
            Project = "ProjectA",
            Name = "Azure Service Bus",
            Type = "Message Queue / Broker",
            Direction = "Downstream",
            Confidence = "Detected in source",
            SourceFile = report.FunctionDependencies[0].File,
            FunctionName = "Workflow.Process()"
        });

        var result = new ChangeImpactAnalyzer().Analyze(report, "Workflow.Process()");

        Assert.Contains(result.ExternalDependencies, x => x.Contains("Azure Service Bus"));
    }

    [Fact]
    public void Analyze_DependencyTarget_FindsFunctionsUsingDependency()
    {
        var report = CreateReport();
        report.Dependencies.Add(new DependencyUsage
        {
            Project = "ProjectA",
            Name = "Azure Service Bus",
            Type = "Message Queue / Broker",
            Direction = "Downstream",
            Confidence = "Detected in source",
            SourceFile = report.FunctionDependencies[0].File,
            FunctionName = "Workflow.Process()"
        });

        var result = new ChangeImpactAnalyzer().Analyze(report, "Azure Service Bus");

        Assert.Contains(result.MatchedFunctions, x => x.Contains("Workflow.Process()"));
    }

    [Fact]
    public void Analyze_UnknownTarget_ReturnsNoMatchSummary()
    {
        var report = CreateReport();
        var result = new ChangeImpactAnalyzer().Analyze(report, "DoesNotExist()");

        Assert.Empty(result.MatchedFunctions);
        Assert.Contains("No matching", result.Summary, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Analyze_EmptyTarget_ThrowsArgumentException()
    {
        var report = CreateReport();

        Assert.Throws<ArgumentException>(() =>
            new ChangeImpactAnalyzer().Analyze(report, " "));
    }

    private static DependencyReport CreateReport()
    {
        var file = Path.Combine(Path.GetTempPath(), "ProjectA", "Workflow.cs");
        return new DependencyReport
        {
            Projects =
            [
                new ProjectResult
                {
                    ProjectName = "ProjectA",
                    ProjectPath = Path.Combine(Path.GetTempPath(), "ProjectA", "ProjectA.csproj"),
                    TargetFramework = "net8.0"
                }
            ],
            FunctionDependencies =
            [
                // Start -> Process
                new FunctionDependencyInfo
                {
                    Function = "Workflow.Start()", File = file, Project = "ProjectA",
                    Direction = "Downstream", DependencyFunction = "Workflow.Process()",
                    DependencyLocation = "Workflow.cs:10", DependencyType = "Internal Function"
                },
                new FunctionDependencyInfo
                {
                    Function = "Workflow.Process()", File = file, Project = "ProjectA",
                    Direction = "Upstream", DependencyFunction = "Workflow.Start()",
                    DependencyLocation = "Workflow.cs:5", DependencyType = "Internal Function"
                },

                // Process -> Validate
                new FunctionDependencyInfo
                {
                    Function = "Workflow.Process()", File = file, Project = "ProjectA",
                    Direction = "Downstream", DependencyFunction = "Workflow.Validate()",
                    DependencyLocation = "Workflow.cs:20", DependencyType = "Internal Function"
                },
                new FunctionDependencyInfo
                {
                    Function = "Workflow.Validate()", File = file, Project = "ProjectA",
                    Direction = "Upstream", DependencyFunction = "Workflow.Process()",
                    DependencyLocation = "Workflow.cs:15", DependencyType = "Internal Function"
                },

                // Process -> Save
                new FunctionDependencyInfo
                {
                    Function = "Workflow.Process()", File = file, Project = "ProjectA",
                    Direction = "Downstream", DependencyFunction = "Workflow.Save()",
                    DependencyLocation = "Workflow.cs:30", DependencyType = "Internal Function"
                },
                new FunctionDependencyInfo
                {
                    Function = "Workflow.Save()", File = file, Project = "ProjectA",
                    Direction = "Upstream", DependencyFunction = "Workflow.Process()",
                    DependencyLocation = "Workflow.cs:15", DependencyType = "Internal Function"
                }
            ]
        };
    }
}
