using DotNetDependencyAgent;

namespace DotNetDependencyAgent.Tests;

public sealed class DependencyAnalyzerTests : IDisposable
{
    private readonly string _root;

    public DependencyAnalyzerTests()
    {
        _root = Path.Combine(Path.GetTempPath(), "DotNetDependencyAgent.Tests", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(_root);
    }

    [Fact]
    public async Task AnalyzeAsync_DiscoversConfirmedUpstreamAndDownstreamProjectReferences()
    {
        var fixture = CreateFixture(
            includeSourceSignals: false,
            includePackages: false);

        var analyzer = new DependencyAnalyzer();

        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        Assert.Equal("ProjectA", Path.GetFileNameWithoutExtension(result.Report.SelectedProject));
        Assert.Equal(2, result.Report.Projects.Count);

        var aDownstream = Assert.Single(result.Report.ProjectDependencies.Where(x =>
            x.Project == "ProjectA" &&
            x.RelatedProject == "ProjectB" &&
            x.Direction == "Downstream"));

        Assert.Equal("ProjectReference", aDownstream.Relationship);
        Assert.Equal("Confirmed", aDownstream.Confidence);

        var bUpstream = Assert.Single(result.Report.ProjectDependencies.Where(x =>
            x.Project == "ProjectB" &&
            x.RelatedProject == "ProjectA" &&
            x.Direction == "Upstream"));

        Assert.Equal("Reverse ProjectReference", bUpstream.Relationship);
        Assert.Equal("Confirmed", bUpstream.Confidence);
    }

    [Fact]
    public async Task AnalyzeAsync_DetectsSourceLevelUpstreamAndDownstreamDependencies()
    {
        var fixture = CreateFixture(
            includeSourceSignals: true,
            includePackages: false);

        var analyzer = new DependencyAnalyzer();

        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        var projectA = result.Report.UniqueDependencySummary
            .Where(x => x.Project == "ProjectA")
            .ToList();

        Assert.Contains(projectA, x =>
            x.Name == "HTTP Endpoint" &&
            x.Direction == "Upstream" &&
            x.Confidence == "Detected in source");

        Assert.Contains(projectA, x =>
            x.Name == "HttpClient / External REST API" &&
            x.Direction == "Downstream" &&
            x.Confidence == "Detected in source");

        Assert.Contains(projectA, x =>
            x.Name == "SQL / Relational Database" &&
            x.Direction == "Downstream" &&
            x.Confidence == "Detected in source");

        Assert.Contains(projectA, x =>
            x.Name == "Azure Service Bus Consumer" &&
            x.Direction == "Upstream" &&
            x.Confidence == "Detected in source");

        Assert.Contains(projectA, x =>
            x.Name == "Azure Service Bus Producer" &&
            x.Direction == "Downstream" &&
            x.Confidence == "Detected in source");
    }

    [Fact]
    public async Task AnalyzeAsync_DetectsPackageHeuristicsAsPossibleDependencies()
    {
        var fixture = CreateFixture(
            includeSourceSignals: false,
            includePackages: true);

        var analyzer = new DependencyAnalyzer();

        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        Assert.Contains(result.Report.Dependencies, x =>
            x.Project.EndsWith("ProjectA.csproj", StringComparison.OrdinalIgnoreCase) &&
            x.Name == "SQL Server" &&
            x.Direction == "Downstream" &&
            x.Confidence == "Possible (package heuristic)");

        Assert.Contains(result.Report.Dependencies, x =>
            x.Project.EndsWith("ProjectA.csproj", StringComparison.OrdinalIgnoreCase) &&
            x.Name == "Azure Service Bus" &&
            x.Direction == "Possible Both" &&
            x.Confidence == "Possible (package heuristic)");
    }

    [Fact]
    public async Task AnalyzeAsync_BuildsFunctionCallGraph()
    {
        var fixture = CreateFixture(
            includeSourceSignals: false,
            includePackages: false,
            sourceForProjectA: """
                namespace ProjectA;

                public sealed class Workflow
                {
                    public void Start()
                    {
                        ProcessOrder();
                    }

                    private void ProcessOrder()
                    {
                    }
                }
                """);

        var analyzer = new DependencyAnalyzer();

        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        Assert.Equal(2, result.Report.CallGraph.Statistics["total_functions"]);
        Assert.Contains(result.Report.CallGraph.Functions, x => x.Name == "Start");
        Assert.Contains(result.Report.CallGraph.Functions, x => x.Name == "ProcessOrder");
        Assert.Contains(result.Report.CallGraph.Edges, x =>
            x.Caller == "Start" && x.Callee == "ProcessOrder");

        Assert.True(File.Exists(result.CallGraphPath));
        Assert.True(File.Exists(result.ReportPath));
    }


    [Fact]
    public async Task AnalyzeAsync_BuildsFunctionUpstreamAndDownstreamRelationshipsForMultipleDependencies()
    {
        var fixture = CreateFixture(
            includeSourceSignals: false,
            includePackages: false,
            sourceForProjectA: """
                namespace ProjectA;

                public sealed class Workflow
                {
                    public void Start()
                    {
                        Validate();
                        Save();
                    }

                    private void Validate()
                    {
                        Save();
                    }

                    private void Save()
                    {
                    }
                }
                """);

        var analyzer = new DependencyAnalyzer();
        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        Assert.Contains(result.Report.FunctionDependencies, x =>
            x.Function == "Workflow.Start()" &&
            x.Direction == "Downstream" &&
            x.DependencyFunction == "Workflow.Validate()" &&
            x.DependencyType == "Internal Function");

        Assert.Contains(result.Report.FunctionDependencies, x =>
            x.Function == "Workflow.Start()" &&
            x.Direction == "Downstream" &&
            x.DependencyFunction == "Workflow.Save()" &&
            x.DependencyType == "Internal Function");

        Assert.Contains(result.Report.FunctionDependencies, x =>
            x.Function == "Workflow.Validate()" &&
            x.Direction == "Upstream" &&
            x.DependencyFunction == "Workflow.Start()" &&
            x.DependencyType == "Internal Function");

        Assert.Contains(result.Report.FunctionDependencies, x =>
            x.Function == "Workflow.Save()" &&
            x.Direction == "Upstream" &&
            x.DependencyFunction == "Workflow.Validate()" &&
            x.DependencyType == "Internal Function");

        Assert.All(result.Report.FunctionDependencies.Where(x => x.DependencyType == "Internal Function"), x =>
            Assert.Contains("depends", x.DependencyStatement, StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public async Task AnalyzeAsync_ResolvesThirdPartyMethodFromAvailableDllMetadata()
    {
        var fixture = CreateFixture(
            includeSourceSignals: false,
            includePackages: false,
            sourceForProjectA: """
                namespace ProjectA;

                public sealed class Workflow
                {
                    public void Start()
                    {
                        ThirdParty.Component.Send();
                    }
                }
                """);

        var thirdPartySource = """
            namespace ThirdParty;
            public static class Component
            {
                public static void Send() { }
            }
            """;

        var thirdPartyDir = Path.Combine(Path.GetDirectoryName(fixture.ProjectA)!, "bin", "thirdparty");
        Directory.CreateDirectory(thirdPartyDir);
        var thirdPartyDll = Path.Combine(thirdPartyDir, "ThirdParty.dll");
        BuildAssembly(thirdPartySource, thirdPartyDll);

        var analyzer = new DependencyAnalyzer();
        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        var dependency = Assert.Single(result.Report.FunctionDependencies.Where(x =>
            x.Function == "Workflow.Start()" &&
            x.DependencyType == "Third Party / External" &&
            x.DependencyFunction.Contains("Component.Send()", StringComparison.Ordinal)));

        Assert.Contains("ThirdParty.dll", dependency.DependencyLocation, StringComparison.OrdinalIgnoreCase);
        Assert.Equal("Resolved from DLL metadata", dependency.Confidence);
        Assert.Contains("Workflow.Start() depends on", dependency.DependencyStatement);
    }

    [Fact]
    public async Task AnalyzeAsync_IncludesFunctionsWithNoDetectedDependencies()
    {
        var fixture = CreateFixture(
            includeSourceSignals: false,
            includePackages: false,
            sourceForProjectA: """
                namespace ProjectA;

                public sealed class Workflow
                {
                    public void Start()
                    {
                    }

                    public void Validate()
                    {
                        Start();
                    }

                    public void Save()
                    {
                    }
                }
                """);

        var analyzer = new DependencyAnalyzer();
        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        Assert.Contains(result.Report.FunctionDependencies, x =>
            x.Function == "Workflow.Start()" && x.Direction == "Upstream" &&
            x.DependencyFunction == "Workflow.Validate()");

        Assert.Contains(result.Report.FunctionDependencies, x =>
            x.Function == "Workflow.Validate()" && x.Direction == "Downstream" &&
            x.DependencyFunction == "Workflow.Start()");

        Assert.Contains(result.Report.FunctionDependencies, x =>
            x.Function == "Workflow.Save()" && x.Direction == "None" &&
            x.DependencyFunction == "—");
    }

    [Fact]
    public void DependencyStatements_RespectDirection()
    {
        var upstream = new ProjectDependencyInfo
        {
            Project = "ProjectB",
            RelatedProject = "ProjectA",
            Direction = "Upstream"
        };
        var downstream = new ProjectDependencyInfo
        {
            Project = "ProjectA",
            RelatedProject = "ProjectB",
            Direction = "Downstream"
        };

        Assert.Equal("ProjectA depends on ProjectB", upstream.DependencyStatement);
        Assert.Equal("ProjectA depends on ProjectB", downstream.DependencyStatement);
    }

    [Fact]
    public void UniqueDependencyStatements_RespectDirection()
    {
        var upstream = new UniqueDependency
        {
            Project = "backend",
            Name = "Azure Function Trigger",
            Direction = "Upstream"
        };
        var downstream = new UniqueDependency
        {
            Project = "backend",
            Name = "Application Insights",
            Direction = "Downstream"
        };

        Assert.Equal("Azure Function Trigger depends on backend", upstream.DependencyStatement);
        Assert.Equal("backend depends on Application Insights", downstream.DependencyStatement);
    }

    [Fact]
    public async Task AnalyzeAsync_ThrowsForMissingProjectFile()
    {
        var analyzer = new DependencyAnalyzer();
        var missing = Path.Combine(_root, "Missing.csproj");

        await Assert.ThrowsAsync<FileNotFoundException>(() => analyzer.AnalyzeAsync(missing));
    }

    [Fact]
    public async Task AnalyzeAsync_HonorsCancellation()
    {
        var fixture = CreateFixture(
            includeSourceSignals: true,
            includePackages: true);

        using var cts = new CancellationTokenSource();
        cts.Cancel();

        var analyzer = new DependencyAnalyzer();

        await Assert.ThrowsAnyAsync<OperationCanceledException>(
            () => analyzer.AnalyzeAsync(fixture.ProjectA, cts.Token));
    }

    [Fact]
    public async Task AnalyzeAsync_AssignsSourceFilesToTheCorrectProject()
    {
        var fixture = CreateFixture(
            includeSourceSignals: true,
            includePackages: false,
            sourceForProjectA: """
                namespace ProjectA;

                public sealed class Api
                {
                    [HttpGet]
                    public void Get()
                    {
                    }
                }
                """,
            sourceForProjectB: """
                namespace ProjectB;

                public sealed class Repository
                {
                    public void Save()
                    {
                        using var client = new HttpClient();
                    }
                }
                """);

        var analyzer = new DependencyAnalyzer();

        var result = await analyzer.AnalyzeAsync(fixture.ProjectA);

        Assert.Contains(result.Report.Dependencies, x =>
            x.Project == fixture.ProjectA &&
            x.Name == "HTTP Endpoint");

        Assert.Contains(result.Report.Dependencies, x =>
            x.Project == fixture.ProjectB &&
            x.Name == "HttpClient / External REST API");

        Assert.DoesNotContain(result.Report.Dependencies, x =>
            x.Project == fixture.ProjectA &&
            x.Name == "HttpClient / External REST API" &&
            x.SourceFile.EndsWith("Repository.cs", StringComparison.OrdinalIgnoreCase));
    }

    private static void BuildAssembly(string source, string outputPath)
    {
        var tree = Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree.ParseText(source);
        var references = ((string?)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") ?? "")
            .Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries)
            .Select(Microsoft.CodeAnalysis.MetadataReference.CreateFromFile)
            .ToList();
        var compilation = Microsoft.CodeAnalysis.CSharp.CSharpCompilation.Create(
            "ThirdParty",
            [tree],
            references,
            new Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions(Microsoft.CodeAnalysis.OutputKind.DynamicallyLinkedLibrary));

        using var stream = File.Create(outputPath);
        var emit = compilation.Emit(stream);
        Assert.True(emit.Success, string.Join(Environment.NewLine, emit.Diagnostics));
    }

    private Fixture CreateFixture(
        bool includeSourceSignals,
        bool includePackages,
        string? sourceForProjectA = null,
        string? sourceForProjectB = null)
    {
        var solution = Path.Combine(_root, "Fixture.sln");
        File.WriteAllText(solution, "");

        var projectADir = Path.Combine(_root, "ProjectA");
        var projectBDir = Path.Combine(_root, "ProjectB");
        Directory.CreateDirectory(projectADir);
        Directory.CreateDirectory(projectBDir);

        var projectA = Path.Combine(projectADir, "ProjectA.csproj");
        var projectB = Path.Combine(projectBDir, "ProjectB.csproj");

        var packageReferences = includePackages
            ? """
              <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.0" />
              <PackageReference Include="Azure.Messaging.ServiceBus" Version="7.18.0" />
              """
            : "";

        File.WriteAllText(projectA, $$"""
            <Project Sdk="Microsoft.NET.Sdk">
              <PropertyGroup>
                <TargetFramework>net8.0</TargetFramework>
              </PropertyGroup>
              <ItemGroup>
                <ProjectReference Include="..\ProjectB\ProjectB.csproj" />
                {{packageReferences}}
              </ItemGroup>
            </Project>
            """);

        File.WriteAllText(projectB, """
            <Project Sdk="Microsoft.NET.Sdk">
              <PropertyGroup>
                <TargetFramework>net8.0</TargetFramework>
              </PropertyGroup>
            </Project>
            """);

        File.WriteAllText(
            Path.Combine(projectADir, "Api.cs"),
            sourceForProjectA ?? (includeSourceSignals
                ? """
                  namespace ProjectA;

                  public sealed class Api
                  {
                      [HttpGet]
                      public void Get()
                      {
                          using var client = new HttpClient();
                          client.GetAsync("https://example.test");
                          using var db = new Microsoft.Data.SqlClient.SqlConnection();
                          db.Open();
                          var sender = new ServiceBusSender();
                          sender.SendMessageAsync(null!);
                      }

                      public void Consume()
                      {
                          var processor = new ServiceBusProcessor();
                          processor.ProcessMessageAsync += (_, _) => Task.CompletedTask;
                      }
                  }
                  """
                : "namespace ProjectA; public sealed class Api { public void Get() { } }"));

        File.WriteAllText(
            Path.Combine(projectBDir, "Repository.cs"),
            sourceForProjectB ?? "namespace ProjectB; public sealed class Repository { public void Save() { } }");

        return new Fixture(projectA, projectB);
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_root))
                Directory.Delete(_root, recursive: true);
        }
        catch
        {
            // Test cleanup should never hide the test result.
        }
    }

    private sealed record Fixture(string ProjectA, string ProjectB);
}
