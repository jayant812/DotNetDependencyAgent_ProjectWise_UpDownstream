using DotNetDependencyAgent;
using Xunit;

namespace DotNetDependencyAgent.Tests;

public sealed class ExternalContextServiceTests : IDisposable
{
    private readonly string _root;

    public ExternalContextServiceTests()
    {
        _root = Path.Combine(Path.GetTempPath(), "DotNetDependencyAgent.ExternalContextTests", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(_root);
    }

    [Fact]
    public void Load_ReadsApiSpecificationAsTextContext()
    {
        var path = Path.Combine(_root, "swagger.json");
        File.WriteAllText(path, "{\"openapi\":\"3.0.0\",\"paths\":{\"/claims\":{\"post\":{}}}}" );

        var result = ExternalContextService.Load(
            [(path, "API Specification")],
            "The claims API is consumed by an external portal.");

        var file = Assert.Single(result.Files);
        Assert.Equal("API Specification", file.Category);
        Assert.Equal("application/json", file.MimeType);
        Assert.Contains("/claims", file.TextContent);
        Assert.Contains("external portal", result.Notes);
    }

    [Fact]
    public void Load_ReadsSequenceDiagramBinaryForAiAttachment()
    {
        var path = Path.Combine(_root, "sequence.png");
        File.WriteAllBytes(path, [1, 2, 3, 4]);

        var result = ExternalContextService.Load(
            [(path, "Sequence Diagram")],
            "");

        var file = Assert.Single(result.Files);
        Assert.Equal("Sequence Diagram", file.Category);
        Assert.Equal("image/png", file.MimeType);
        Assert.Equal(4, file.SizeBytes);
        Assert.Equal([1, 2, 3, 4], file.BinaryContent);
    }

    [Fact]
    public void Load_IgnoresMissingFiles()
    {
        var path = Path.Combine(_root, "missing.json");

        var result = ExternalContextService.Load(
            [(path, "Architecture / Context")],
            "");

        Assert.Empty(result.Files);
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_root)) Directory.Delete(_root, true);
        }
        catch { }
    }
}
