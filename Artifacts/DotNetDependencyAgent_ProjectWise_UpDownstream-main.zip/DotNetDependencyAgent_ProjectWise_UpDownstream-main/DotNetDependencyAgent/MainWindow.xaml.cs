using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Data;

namespace DotNetDependencyAgent;

public partial class MainWindow : Window
{
    private readonly DependencyAnalyzer _analyzer = new();
    private readonly GeminiService _gemini = new();
    private readonly ChangeImpactAnalyzer _changeImpactAnalyzer = new();
    private readonly AppSettings _settings;
    private CancellationTokenSource? _cts;
    private AnalysisResult? _lastResult;
    private List<FunctionDependencyInfo> _functionDependencies = [];
    private readonly List<(string Path, string Category)> _externalContextFiles = [];

    public MainWindow()
    {
        InitializeComponent();
        _settings = AppSettings.Load();
        InputTextBox.Text = "";
        InitializeGeminiModels();
        ResetAiReport("Run an analysis to generate the structured AI impact report.");
        ChangeImpactResultTextBox.Text = "Run an analysis first. Then enter a function, file, project, or dependency and click Analyze Change.";
        RefreshExternalContextList();


        _analyzer.Progress += (p, m) => Dispatcher.Invoke(() =>
        {
            ProgressBar.Value = p;
            ProgressText.Text = m;
        });
        _analyzer.Log += m => Dispatcher.Invoke(() => AppendLog(m));
    }

    private void InitializeGeminiModels()
    {
        // Stable text-generation models suitable for this structured dependency/architecture report.
        var models = new[]
        {
            "gemini-3.8-flash",
            "gemini-3.7-flash",
            "gemini-3.6-flash",
            "gemini-3.5-flash",
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite",
            "gemini-2.5-flash",
            "gemini-2.5-flash-lite",
            "gemini-2.5-pro"
        };

        GeminiModelComboBox.ItemsSource = models;

        var configuredModel = string.IsNullOrWhiteSpace(_settings.Gemini.Model)
            ? "gemini-3.5-flash"
            : _settings.Gemini.Model.Trim();

        GeminiModelComboBox.SelectedItem = models.FirstOrDefault(x =>
            string.Equals(x, configuredModel, StringComparison.OrdinalIgnoreCase));

        if (GeminiModelComboBox.SelectedItem is null)
        {
            GeminiModelComboBox.ItemsSource = models.Append(configuredModel).ToArray();
            GeminiModelComboBox.SelectedItem = configuredModel;
        }
    }

    private void InputModeChanged(object sender, RoutedEventArgs e)
    {
        if (!IsLoaded) return;
        var local = LocalRadio.IsChecked == true;
        BrowseButton.Visibility = local ? Visibility.Visible : Visibility.Collapsed;
        InputTextBox.Text = local ? "" : "";
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Filter = ".NET Solution or Project (*.sln;*.csproj)|*.sln;*.csproj|Visual Studio Solution (*.sln)|*.sln|.NET Project (*.csproj)|*.csproj",
            Title = "Select a .NET solution or project"
        };
        if (dlg.ShowDialog(this) == true) InputTextBox.Text = dlg.FileName;
    }

    private async void Analyze_Click(object sender, RoutedEventArgs e)
    {
        string key = _settings.Gemini.ApiKey?.Trim() ?? string.Empty;
        string model = GeminiModelComboBox.SelectedItem?.ToString()?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(model))
            model = string.IsNullOrWhiteSpace(_settings.Gemini.Model) ? "gemini-3.5-flash" : _settings.Gemini.Model.Trim();
        var input = InputTextBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(input))
        {
            MessageBox.Show(this, "Enter a GitHub repository URL or select a .sln/.csproj file.", "Input required");
            return;
        }

        AnalyzeButton.IsEnabled = false;
        OpenOutputButton.IsEnabled = false;
        ProgressBar.Value = 0;
        ReportTextBox.Clear();
        CallGraphTextBox.Clear();
        FunctionDependenciesGrid.ItemsSource = null;
        FunctionDepsCount.Text = "0 relationships";
        FunctionSearchTextBox.Clear();
        ChangeImpactResultTextBox.Text = "Static analysis is running. Change Impact will be available after analysis completes.";
        LogTextBox.Clear();
        ResetAiReport("AI report is waiting for static dependency analysis to complete...");
        DependenciesGrid.ItemsSource = null;
        ProjectDependenciesGrid.ItemsSource = null;
        _cts = new CancellationTokenSource();
        var externalContext = ExternalContextService.Load(_externalContextFiles, ExternalContextNotesTextBox.Text);

        try
        {
            AppendLog("Starting analysis...");
            _lastResult = await _analyzer.AnalyzeAsync(input, _cts.Token);
            _lastResult.Report.ExternalContext = externalContext;

            var jsonOptions = new JsonSerializerOptions { WriteIndented = true };
            ReportTextBox.Text = JsonSerializer.Serialize(_lastResult.Report, jsonOptions);
            CallGraphTextBox.Text = JsonSerializer.Serialize(_lastResult.Report.CallGraph, jsonOptions);
            var externalContextManifestPath = Path.Combine(_lastResult.OutputDirectory, "external_context_manifest.json");
            await File.WriteAllTextAsync(externalContextManifestPath, JsonSerializer.Serialize(externalContext, jsonOptions), _cts.Token);
            AppendLog($"External context manifest: {externalContextManifestPath}");
            BindSummary(_lastResult.Report);
            ChangeImpactHintText.Text = "Static analysis completed. Enter a function, file, project, or dependency above and click Analyze Change.";
            ChangeImpactResultTextBox.Text = "Ready for change-impact analysis.";

            if (RunAiCheckBox.IsChecked == true)
            {
                if (string.IsNullOrWhiteSpace(key) || key == "PASTE_YOUR_GEMINI_API_KEY_HERE")
                {
                    throw new InvalidOperationException(
                        "Gemini API key is missing. Add it under Gemini:ApiKey in appsettings.json " +
                        "or set the GEMINI_API_KEY environment variable.");
                }
                ProgressBar.Value = 85;
                ProgressText.Text = $"Generating AI report with {model}";
                AppendLog("Selected Gemini model: " + model);

                try
                {
                    var aiReport = await _gemini.AnalyzeAsync(
                        _lastResult.Report,
                        externalContext,
                        key,
                        model,
                        _cts.Token);

                    // Render a native WPF report. We do not display raw Markdown pipes in a TextBox.
                    AiReportBox.Document = AiReportRenderer.CreateDocument(aiReport, _lastResult.Report);

                    // Also save portable report formats to the output folder.
                    var markdown = AiReportFormatter.ToMarkdown(aiReport, _lastResult.Report);
                    var html = AiReportFormatter.ToHtml(aiReport, _lastResult.Report);
                    var architectureSvg = ArchitectureDiagramBuilder.BuildStandaloneSvg(aiReport, _lastResult.Report);
                    var structuredJson = JsonSerializer.Serialize(aiReport, jsonOptions);

                    _lastResult.AiAnalysis = markdown;
                    _lastResult.AiReportPath = Path.Combine(_lastResult.OutputDirectory, "ai_dependency_analysis.md");
                    var htmlPath = Path.Combine(_lastResult.OutputDirectory, "ai_dependency_analysis.html");
                    var svgPath = Path.Combine(_lastResult.OutputDirectory, "project_architecture_diagram.svg");
                    var jsonPath = Path.Combine(_lastResult.OutputDirectory, "ai_dependency_analysis.json");

                    await File.WriteAllTextAsync(_lastResult.AiReportPath, markdown, _cts.Token);
                    await File.WriteAllTextAsync(htmlPath, html, _cts.Token);
                    await File.WriteAllTextAsync(svgPath, architectureSvg, _cts.Token);
                    await File.WriteAllTextAsync(jsonPath, structuredJson, _cts.Token);

                    AppendLog("Structured AI analysis saved: " + _lastResult.AiReportPath);
                    AppendLog("Readable HTML report saved: " + htmlPath);
                    AppendLog("Architecture diagram SVG saved: " + svgPath);
                    AppendLog("Structured AI JSON saved: " + jsonPath);
                }
                catch (Exception aiEx)
                {
                    ResetAiReport(
                        "AI analysis was not completed.\n\n" + aiEx.Message +
                        "\n\nStatic project/dependency analysis is still available in the other tabs.");
                    AppendLog("AI warning: " + aiEx.Message);
                }
            }
            else
            {
                ResetAiReport("AI analysis was disabled for this run. Static dependency results are available in the Summary and Project Dependencies tab.");
            }

            ProgressBar.Value = 100;
            ProgressText.Text = "Analysis completed successfully";
            OpenOutputButton.IsEnabled = true;
            AppendLog("Dependency report: " + _lastResult.ReportPath);
            AppendLog("Call graph: " + _lastResult.CallGraphPath);
        }
        catch (Exception ex)
        {
            ProgressText.Text = "Analysis failed";
            AppendLog("ERROR: " + ex);
            MessageBox.Show(this, ex.Message, "Analysis failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            AnalyzeButton.IsEnabled = true;
        }
    }

    private void BindSummary(DependencyReport report)
    {
        PackagesCount.Text = report.Packages.Count.ToString();
        FilesCount.Text = report.CsFiles.Count.ToString();
        UsagesCount.Text = report.Dependencies.Count.ToString();
        UniqueCount.Text = report.UniqueDependencySummary.Count.ToString();
        RefsCount.Text = report.ProjectReferences.Count.ToString();
        ProjectDepsCount.Text = report.ProjectDependencies.Count.ToString();
        DependenciesGrid.ItemsSource = report.UniqueDependencySummary;
        ProjectDependenciesGrid.ItemsSource = report.ProjectDependencies;
        _functionDependencies = report.FunctionDependencies;
        BindFunctionDependencies();
    }

    private void BindFunctionDependencies()
    {
        var search = FunctionSearchTextBox.Text?.Trim() ?? "";
        var filtered = string.IsNullOrWhiteSpace(search)
            ? _functionDependencies
            : _functionDependencies.Where(x =>
                x.Function.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                x.File.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                x.Project.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                x.DependencyFunction.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                x.DependencyLocation.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                x.DependencyStatement.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();

        var view = CollectionViewSource.GetDefaultView(filtered);
        view.GroupDescriptions.Clear();
        view.GroupDescriptions.Add(new PropertyGroupDescription(nameof(FunctionDependencyInfo.File)));
        FunctionDependenciesGrid.ItemsSource = view;
        var functionCount = filtered.Select(x => $"{x.File}|{x.Function}").Distinct(StringComparer.OrdinalIgnoreCase).Count();
        var relationshipCount = filtered.Count(x => !x.Direction.Equals("None", StringComparison.OrdinalIgnoreCase));
        var fileCount = filtered.Select(x => x.File).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        FunctionDepsCount.Text = $"{functionCount} functions | {relationshipCount} relationships | {fileCount} files";
    }

    private void FunctionSearchTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (!IsLoaded) return;
        BindFunctionDependencies();
    }

    private async void AnalyzeChangeImpact_Click(object sender, RoutedEventArgs e)
    {
        if (_lastResult is null)
        {
            ChangeImpactResultTextBox.Text = "Run Analyze Project first. Change Impact Analysis uses the static dependency report from that analysis.";
            return;
        }

        var requestedTarget = ChangeTargetTextBox.Text?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(requestedTarget))
        {
            ChangeImpactResultTextBox.Text = "Enter a function, file, project, dependency, or natural-language change request.";
            ChangeTargetTextBox.Focus();
            return;
        }

        try
        {
            ChangeImpactResultTextBox.Text = "Resolving the change request...";

            // First try deterministic static matching. This avoids an AI call for an exact
            // function/file/project/dependency target and keeps the original behavior intact.
            var result = _changeImpactAnalyzer.Analyze(_lastResult.Report, requestedTarget);
            var resolvedTarget = requestedTarget;
            var aiResolved = false;

            if (result.MatchedFunctions.Count == 0)
            {
                var apiKey = _settings.Gemini.ApiKey?.Trim() ?? string.Empty;
                var model = GeminiModelComboBox.SelectedItem?.ToString()?.Trim() ?? string.Empty;
                if (string.IsNullOrWhiteSpace(model))
                    model = string.IsNullOrWhiteSpace(_settings.Gemini.Model) ? "gemini-3.5-flash" : _settings.Gemini.Model.Trim();

                if (!string.IsNullOrWhiteSpace(apiKey))
                {
                    var candidate = await _gemini.ResolveChangeTargetAsync(
                        _lastResult.Report,
                        requestedTarget,
                        apiKey,
                        model);

                    if (!string.IsNullOrWhiteSpace(candidate))
                    {
                        var aiResult = _changeImpactAnalyzer.Analyze(_lastResult.Report, candidate);
                        if (aiResult.MatchedFunctions.Count > 0)
                        {
                            resolvedTarget = candidate;
                            result = aiResult;
                            aiResolved = true;
                        }
                    }
                }
            }

            var formatted = FormatChangeImpactResult(result, requestedTarget, resolvedTarget, aiResolved);
            ChangeImpactResultTextBox.Text = formatted;

            if (!string.IsNullOrWhiteSpace(_lastResult.OutputDirectory) &&
                Directory.Exists(_lastResult.OutputDirectory))
            {
                var safeTarget = string.Concat(resolvedTarget.Select(ch =>
                    Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));
                safeTarget = string.IsNullOrWhiteSpace(safeTarget) ? "target" : safeTarget;
                var baseName = $"change_impact_{safeTarget}";
                var textPath = Path.Combine(_lastResult.OutputDirectory, baseName + ".txt");
                var jsonPath = Path.Combine(_lastResult.OutputDirectory, baseName + ".json");
                File.WriteAllText(textPath, formatted);
                File.WriteAllText(jsonPath, JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
                AppendLog("Change impact report saved: " + textPath);
                AppendLog("Change impact JSON saved: " + jsonPath);
            }

            AppendLog(aiResolved
                ? $"AI resolved change request '{requestedTarget}' to '{resolvedTarget}'."
                : $"Change impact analyzed for: {resolvedTarget}");
        }
        catch (Exception ex)
        {
            ChangeImpactResultTextBox.Text = "Change impact analysis failed.\n\n" + ex.Message;
            AppendLog("Change impact error: " + ex);
        }
    }

    private static string FormatChangeImpactResult(ChangeImpactResult result, string requestedTarget, string resolvedTarget, bool aiResolved)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("CHANGE IMPACT ANALYSIS");
        sb.AppendLine(new string('=', 80));
        sb.AppendLine();
        sb.AppendLine("Change Request");
        sb.AppendLine(requestedTarget);
        sb.AppendLine();
        sb.AppendLine("Resolved Target");
        sb.AppendLine(resolvedTarget);
        if (aiResolved)
        {
            sb.AppendLine("Target resolution: Gemini AI matched the natural-language request to an existing code target; impact calculation remains static-analysis based.");
        }
        else
        {
            sb.AppendLine("Target resolution: Static analysis matched the supplied target directly.");
        }
        sb.AppendLine();
        sb.AppendLine("Summary");
        sb.AppendLine(result.Summary);
        sb.AppendLine();

        AppendImpactSection(sb, "Matched Functions", result.MatchedFunctions);
        AppendImpactSection(sb, "Direct Callers (functions that use the target)", result.DirectCallers);
        AppendImpactSection(sb, "Direct Called Functions (functions/services used by the target)", result.DirectCallees);
        AppendImpactSection(sb, "Additional Caller Impact", result.TransitiveCallers);
        AppendImpactSection(sb, "Additional Downstream Impact", result.TransitiveCallees);
        AppendImpactSection(sb, "Impacted Files", result.ImpactedFiles);
        AppendImpactSection(sb, "Impacted Projects", result.ImpactedProjects);
        AppendImpactSection(sb, "External Dependencies to Review", result.ExternalDependencies);
        AppendImpactSection(sb, "Recommended Review Areas", result.RecommendedReviewAreas);

        return sb.ToString();
    }

    private static void AppendImpactSection(System.Text.StringBuilder sb, string title, IEnumerable<string> values)
    {
        sb.AppendLine(title);
        var items = values.Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
        if (items.Count == 0)
        {
            sb.AppendLine("  None identified from the available static evidence.");
        }
        else
        {
            foreach (var item in items)
                sb.AppendLine("  • " + item);
        }
        sb.AppendLine();
    }

    private void AddExternalContextFiles(string category, string filter, string title)
    {
        var dlg = new OpenFileDialog
        {
            Filter = filter,
            Title = title,
            Multiselect = true,
            CheckFileExists = true
        };
        if (dlg.ShowDialog(this) != true) return;

        foreach (var file in dlg.FileNames)
        {
            if (_externalContextFiles.Any(x => x.Path.Equals(file, StringComparison.OrdinalIgnoreCase))) continue;
            _externalContextFiles.Add((file, category));
        }
        RefreshExternalContextList();
    }

    private void AddApiSpec_Click(object sender, RoutedEventArgs e) =>
        AddExternalContextFiles("API Specification", "OpenAPI / Swagger (*.json;*.yaml;*.yml)|*.json;*.yaml;*.yml|JSON (*.json)|*.json|YAML (*.yaml;*.yml)|*.yaml;*.yml|All supported files|*.json;*.yaml;*.yml", "Select API specification");

    private void AddSequenceDiagram_Click(object sender, RoutedEventArgs e) =>
        AddExternalContextFiles("Sequence Diagram", "Diagram / Document (*.png;*.jpg;*.jpeg;*.webp;*.pdf)|*.png;*.jpg;*.jpeg;*.webp;*.pdf|Images (*.png;*.jpg;*.jpeg;*.webp)|*.png;*.jpg;*.jpeg;*.webp|PDF (*.pdf)|*.pdf", "Select sequence diagram");

    private void AddContextFile_Click(object sender, RoutedEventArgs e) =>
        AddExternalContextFiles("Architecture / Context", "Context files (*.txt;*.md;*.json;*.yaml;*.yml;*.xml;*.csv;*.pdf)|*.txt;*.md;*.json;*.yaml;*.yml;*.xml;*.csv;*.pdf|All supported files|*.txt;*.md;*.json;*.yaml;*.yml;*.xml;*.csv;*.pdf", "Select architecture or context file");

    private void ClearExternalContext_Click(object sender, RoutedEventArgs e)
    {
        _externalContextFiles.Clear();
        ExternalContextNotesTextBox.Clear();
        RefreshExternalContextList();
    }

    private void RefreshExternalContextList()
    {
        ExternalContextFilesListBox.ItemsSource = _externalContextFiles
            .Select(x => new ExternalContextListItem
            {
                DisplayName = $"[{x.Category}] {Path.GetFileName(x.Path)}"
            })
            .ToList();
    }

    private sealed class ExternalContextListItem
    {
        public string DisplayName { get; init; } = "";
    }

    private void ResetAiReport(string message)
    {
        var document = new FlowDocument
        {
            FontFamily = new System.Windows.Media.FontFamily("Segoe UI"),
            FontSize = 13,
            PagePadding = new Thickness(22)
        };
        document.Blocks.Add(new Paragraph(new Run(message))
        {
            Foreground = System.Windows.Media.Brushes.DimGray
        });
        AiReportBox.Document = document;
    }

    private void AppendLog(string message)
    {
        LogTextBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\r\n");
        LogTextBox.ScrollToEnd();
    }

    private void OpenOutput_Click(object sender, RoutedEventArgs e)
    {
        if (_lastResult is null || !Directory.Exists(_lastResult.OutputDirectory)) return;
        Process.Start(new ProcessStartInfo("explorer.exe", $"\"{_lastResult.OutputDirectory}\"")
        {
            UseShellExecute = true
        });
    }
}
