# .NET Dependency Agent - Dependency Analysis Edition

.NET 8 WPF desktop application for analyzing GitHub repositories or local .NET projects.

## What this version adds

- Confirmed project-to-project dependency direction from `<ProjectReference>`.
  - A project it references is **Downstream**.
  - A project that references it is **Upstream**.
- Local `.csproj` mode scans the nearby `.sln`/Git repository when available so reverse references can be found.
- Expanded package heuristics for databases, caches, queues/brokers, REST/gRPC, Azure/AWS, email, identity, search, telemetry, scheduling, storage, payments, testing, and more.
- Source-level producer/consumer refinements for Service Bus, RabbitMQ, Kafka, MassTransit and other common patterns.
- Confidence labels distinguish **Confirmed**, **Detected in source**, and **Possible (package heuristic)** results.
- Dedicated **Project Dependencies** UI tab.
- Git long-path protection using a short clone path (`C:\DDA\r\<id>`) and `git -c core.longpaths=true clone --depth 1`.

## Important interpretation

Package names are evidence of a possible integration, but often cannot prove direction. For example, a Kafka package could mean producer, consumer, or both. Source scanning is used to refine this when recognizable APIs are found. ProjectReference direction is considered confirmed.

## Run

1. Open `DotNetDependencyAgent.sln` in Visual Studio 2022.
2. Ensure the .NET 8 SDK and **.NET desktop development** workload are installed.
3. Press F5 or Ctrl+F5.
4. Select GitHub Repository URL or Local `.csproj`.
5. Click **Analyze Project**.

Gemini analysis is optional. Provide the API key in the application or via `GEMINI_API_KEY`.

## Structured AI Impact Report
The AI report no longer relies on raw Markdown rendering inside a TextBox. Gemini returns a strict JSON structure and the WPF application renders it as a native FlowDocument with headings and real tables. The output directory also contains:
- `ai_dependency_analysis.html` - clean browser-readable report
- `ai_dependency_analysis.md` - portable Markdown report
- `ai_dependency_analysis.json` - structured AI response for automation/integration

Report order: Executive Summary, Key Metrics, Confirmed Project Relationships, Upstream, Downstream, Bidirectional/Possible, Entry Points, Dependency Flow, Overall Assessment, Risks, Recommendations, Analysis Notes.

## Project-wise AI dependency report

The AI Impact Report now renders every discovered `.csproj` in a separate section. Each project has its own Upstream, Downstream, Bidirectional/Possible dependencies, Entry Points, Dependency Flow, Risks, Recommendations, and Notes. Confirmed `ProjectReference` and reverse-reference relationships are injected from static analysis so a project section is still present even if the AI response omits it. Package/source heuristics are grouped only under their owning project.


## Project Architecture in Gemini report
The AI report now includes a repository-level **Project Architecture** section with architecture style, overview, components, confirmed/possible connections, architecture flow, and evidence notes. Every discovered `.csproj` is deterministically added as a Confirmed architecture component, and confirmed downstream `ProjectReference` relationships are deterministically added as `Project -> Project` architecture connections even if Gemini omits them. Gemini may enrich the architecture with API/database/queue/cache/storage/external components only when the static dependency report contains supporting evidence.


## Gemini configuration
Gemini settings are loaded from `appsettings.json`; the API key is no longer hard-coded in `MainWindow.xaml.cs`.

```json
{
  "Gemini": {
    "ApiKey": "PASTE_YOUR_GEMINI_API_KEY_HERE",
    "Model": "gemini-3.5-flash"
  }
}
```

For deployments, `GEMINI_API_KEY` and `GEMINI_MODEL` environment variables can override the file values. Do not commit a real API key to source control.


## Gemini model dropdown
The desktop UI now provides a Gemini model dropdown. `Gemini:Model` in `appsettings.json` controls the default selection only. The model selected on screen is passed to `GeminiService` for that analysis run and is written to the activity log. The API key continues to come from `appsettings.json` or the `GEMINI_API_KEY` environment variable.

## Visual project architecture diagram

AI reports now include a dynamic visual architecture diagram generated from the discovered projects, entry points, ProjectReference relationships, and evidence-backed external dependencies.

- HTML report: designed SVG blocks, arrows, relationship labels, confidence styling, and legend.
- WPF AI Report tab: block-based architecture preview.
- Markdown report: Mermaid architecture diagram source.
- Output folder: `project_architecture_diagram.svg` for reuse in documentation or presentations.
- Solid arrows represent confirmed/high-confidence relationships; dashed arrows represent possible/low-confidence relationships.
- The diagram uses static scan evidence plus Gemini's evidence-backed architecture model and does not intentionally invent missing components.

### Function-level dependency analysis

The application now includes a **Function Up/Downstream** tab. It inventories methods across all discovered C# files, groups them by file, and resolves source-level caller/callee relationships. Referenced third-party methods are reported with the containing type, method and DLL/assembly location when Roslyn metadata is available. The AI Impact Report also contains a separate, file-grouped function dependency section with descriptive upstream/downstream explanations.

## Phase 1 - External Context Analysis

The application now accepts evidence outside the source code so the AI report can use architecture/context information in addition to `.csproj`, C# and package analysis.

- **API Spec...** accepts OpenAPI/Swagger JSON or YAML.
- **Sequence Diagram...** accepts PNG/JPG/WebP images or PDF documents. Binary diagrams are sent to Gemini as multimodal input.
- **Context File...** accepts architecture notes and text/JSON/YAML/XML/CSV/PDF context.
- The **Additional context** field accepts short architecture or business notes that are not present in source code.
- External inputs are recorded in `external_context_manifest.json` and their metadata is included in `dependency_report.json`.
- The AI report has a separate **External Context Analysis** section covering key facts, API specification observations, sequence-diagram observations, impact considerations, and limitations.
- External context is treated as supplementary evidence. It is not silently promoted to confirmed source-code dependency evidence when the two sources disagree.

The UI terminology has also been simplified: the main tabs are **Project Dependencies** and **Function Dependencies**. The internal direction model remains available for deterministic analysis and AI reasoning.

## Local solution (.sln) analysis

You can select a `.sln` file in Local mode. The agent reads the solution file, extracts only the `.csproj` projects included in that solution, and analyzes those projects sequentially. After all solution projects are loaded, it runs the combined source/dependency/function analysis and then the optional Gemini AI report over the aggregated report.

This prevents unrelated `.csproj` files elsewhere in the same repository folder from being included accidentally.
