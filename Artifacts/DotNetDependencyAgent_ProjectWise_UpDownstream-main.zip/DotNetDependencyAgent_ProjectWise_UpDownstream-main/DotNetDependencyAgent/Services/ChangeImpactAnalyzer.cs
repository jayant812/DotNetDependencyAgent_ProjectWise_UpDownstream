using System.IO;
using System.Text;

namespace DotNetDependencyAgent;

/// <summary>
/// Performs deterministic change-impact analysis from the static dependency report.
/// No AI call is required; the result is derived only from source/project evidence.
/// </summary>
public sealed class ChangeImpactAnalyzer
{
    public ChangeImpactResult Analyze(DependencyReport report, string changeTarget)
    {
        if (report is null)
            throw new ArgumentNullException(nameof(report));

        var target = changeTarget?.Trim() ?? string.Empty;
        if (target.Length == 0)
            throw new ArgumentException("Enter a function, file, project, or dependency to analyze.", nameof(changeTarget));

        var matches = FindTargets(report, target);
        if (matches.Count == 0)
        {
            return new ChangeImpactResult
            {
                Query = target,
                Summary = $"No matching function, file, project, or dependency was found for '{target}'."
            };
        }

        var internalEdges = BuildInternalFunctionGraph(report.FunctionDependencies);
        var matchedKeys = matches.Select(GetFunctionKey).ToHashSet(StringComparer.OrdinalIgnoreCase);

        var directCallers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var directCallees = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var allCallers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var allCallees = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var external = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var impactedProjects = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var impactedFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var match in matches)
        {
            impactedFiles.Add(match.File);
            impactedProjects.Add(match.Project);

            foreach (var edge in internalEdges.Where(x => x.To.Equals(GetFunctionKey(match), StringComparison.OrdinalIgnoreCase)))
                directCallers.Add(edge.From);

            foreach (var edge in internalEdges.Where(x => x.From.Equals(GetFunctionKey(match), StringComparison.OrdinalIgnoreCase)))
                directCallees.Add(edge.To);

            foreach (var dependency in report.FunctionDependencies.Where(x =>
                         x.File.Equals(match.File, StringComparison.OrdinalIgnoreCase) &&
                         x.Function.Equals(match.Function, StringComparison.OrdinalIgnoreCase)))
            {
                if (!dependency.Direction.Equals("None", StringComparison.OrdinalIgnoreCase) &&
                    !dependency.DependencyFunction.Equals("—", StringComparison.OrdinalIgnoreCase))
                {
                    if (!dependency.DependencyType.Equals("Internal Function", StringComparison.OrdinalIgnoreCase))
                        external.Add(FormatDependency(dependency));
                }
            }
        }

        ExpandGraph(internalEdges, directCallers, allCallers, reverse: true);
        ExpandGraph(internalEdges, directCallees, allCallees, reverse: false);

        // Remove the direct set from transitive-only results so the UI clearly separates them.
        allCallers.ExceptWith(directCallers);
        allCallees.ExceptWith(directCallees);

        foreach (var function in report.FunctionDependencies)
        {
            if (matches.Any(m =>
                    m.File.Equals(function.File, StringComparison.OrdinalIgnoreCase) &&
                    m.Function.Equals(function.Function, StringComparison.OrdinalIgnoreCase)))
                continue;

            if (directCallers.Contains(GetFunctionKey(function)) || allCallers.Contains(GetFunctionKey(function)) ||
                directCallees.Contains(GetFunctionKey(function)) || allCallees.Contains(GetFunctionKey(function)))
            {
                impactedFiles.Add(function.File);
                impactedProjects.Add(function.Project);
            }
        }

        // Project-level consumers of the target project.
        foreach (var project in matches.Select(x => x.Project).Distinct(StringComparer.OrdinalIgnoreCase))
        {
            foreach (var relationship in report.ProjectDependencies.Where(x =>
                         x.RelatedProject.Equals(project, StringComparison.OrdinalIgnoreCase) &&
                         x.Direction.Equals("Downstream", StringComparison.OrdinalIgnoreCase)))
            {
                impactedProjects.Add(relationship.Project);
            }

            foreach (var relationship in report.ProjectDependencies.Where(x =>
                         x.Project.Equals(project, StringComparison.OrdinalIgnoreCase) &&
                         x.Direction.Equals("Upstream", StringComparison.OrdinalIgnoreCase)))
            {
                impactedProjects.Add(relationship.RelatedProject);
            }
        }

        // Source-level external dependencies tied to the target file/function.
        foreach (var usage in report.Dependencies.Where(x =>
                     matches.Any(m =>
                         (!string.IsNullOrWhiteSpace(x.SourceFile) &&
                          x.SourceFile.Equals(m.File, StringComparison.OrdinalIgnoreCase)) ||
                         (!string.IsNullOrWhiteSpace(x.FunctionName) &&
                          x.FunctionName.Equals(m.Function, StringComparison.OrdinalIgnoreCase)))))
        {
            if (usage.Direction.Equals("Downstream", StringComparison.OrdinalIgnoreCase) ||
                usage.Direction.Equals("Possible Both", StringComparison.OrdinalIgnoreCase))
            {
                external.Add($"{usage.Name} ({usage.Type})");
            }
        }

        var result = new ChangeImpactResult
        {
            Query = target,
            MatchedFunctions = matches.Select(DescribeFunction).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList(),
            DirectCallers = directCallers.Select(FormatFunctionKey).OrderBy(x => x).ToList(),
            DirectCallees = directCallees.Select(FormatFunctionKey).OrderBy(x => x).ToList(),
            TransitiveCallers = allCallers.Select(FormatFunctionKey).OrderBy(x => x).ToList(),
            TransitiveCallees = allCallees.Select(FormatFunctionKey).OrderBy(x => x).ToList(),
            ImpactedFiles = impactedFiles.Where(x => !string.IsNullOrWhiteSpace(x)).OrderBy(x => x).ToList(),
            ImpactedProjects = impactedProjects.Where(x => !string.IsNullOrWhiteSpace(x)).OrderBy(x => x).ToList(),
            ExternalDependencies = external.OrderBy(x => x).ToList()
        };

        result.Summary = BuildSummary(result);
        result.RecommendedReviewAreas = BuildReviewAreas(result);
        return result;
    }

    private static List<FunctionDependencyInfo> FindTargets(DependencyReport report, string query)
    {
        var normalized = query.Trim();
        var fileQuery = Path.GetFileName(normalized);
        var withoutExtension = Path.GetFileNameWithoutExtension(normalized);

        var all = report.FunctionDependencies
            .GroupBy(x => $"{x.File}|{x.Function}", StringComparer.OrdinalIgnoreCase)
            .Select(x => x.First())
            .ToList();

        var exactFunction = all.Where(x =>
            x.Function.Equals(normalized, StringComparison.OrdinalIgnoreCase)).ToList();
        if (exactFunction.Count > 0) return exactFunction;

        var functionName = normalized.EndsWith("()", StringComparison.Ordinal)
            ? normalized[..^2]
            : normalized;

        var nameMatches = all.Where(x =>
            x.Function.Equals(functionName, StringComparison.OrdinalIgnoreCase) ||
            x.Function.EndsWith("." + functionName + "()", StringComparison.OrdinalIgnoreCase) ||
            x.Function.EndsWith("." + functionName, StringComparison.OrdinalIgnoreCase)).ToList();
        if (nameMatches.Count > 0) return nameMatches;

        var fileMatches = all.Where(x =>
            Path.GetFileName(x.File).Equals(fileQuery, StringComparison.OrdinalIgnoreCase) ||
            Path.GetFileNameWithoutExtension(x.File).Equals(withoutExtension, StringComparison.OrdinalIgnoreCase) ||
            x.File.Contains(normalized, StringComparison.OrdinalIgnoreCase)).ToList();
        if (fileMatches.Count > 0) return fileMatches;

        var projectMatches = all.Where(x =>
            x.Project.Equals(normalized, StringComparison.OrdinalIgnoreCase) ||
            Path.GetFileNameWithoutExtension(x.Project).Equals(withoutExtension, StringComparison.OrdinalIgnoreCase)).ToList();
        if (projectMatches.Count > 0) return projectMatches;

        // A dependency can also be the requested change target, for example
        // "Azure Service Bus" or "HttpClient / External REST API". In that case
        // return the source functions/files that directly use the dependency.
        var dependencyMatches = report.FunctionDependencies.Where(x =>
            !x.DependencyFunction.Equals("—", StringComparison.OrdinalIgnoreCase) &&
            x.DependencyFunction.Contains(normalized, StringComparison.OrdinalIgnoreCase) &&
            !x.DependencyType.Equals("Internal Function", StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (dependencyMatches.Count > 0) return dependencyMatches;

        var usageMatches = report.Dependencies.Where(x =>
            x.Name.Contains(normalized, StringComparison.OrdinalIgnoreCase) ||
            normalized.Contains(x.Name, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (usageMatches.Count > 0)
        {
            return all.Where(function => usageMatches.Any(usage =>
                (!string.IsNullOrWhiteSpace(usage.SourceFile) &&
                 usage.SourceFile.Equals(function.File, StringComparison.OrdinalIgnoreCase)) ||
                (!string.IsNullOrWhiteSpace(usage.FunctionName) &&
                 usage.FunctionName.Equals(function.Function, StringComparison.OrdinalIgnoreCase))))
                .ToList();
        }

        return [];
    }

    private static List<ImpactEdge> BuildInternalFunctionGraph(IEnumerable<FunctionDependencyInfo> dependencies)
    {
        var items = dependencies.ToList();
        var functions = items
            .Where(x => !x.Direction.Equals("None", StringComparison.OrdinalIgnoreCase))
            .GroupBy(x => $"{x.File}|{x.Function}", StringComparer.OrdinalIgnoreCase)
            .Select(x => x.First())
            .ToList();

        var edges = new List<ImpactEdge>();

        foreach (var dependency in items.Where(x =>
                     x.DependencyType.Equals("Internal Function", StringComparison.OrdinalIgnoreCase) &&
                     !x.DependencyFunction.Equals("—", StringComparison.OrdinalIgnoreCase)))
        {
            var currentKey = GetFunctionKey(dependency);
            var dependencyItem = ResolveDependencyFunction(functions, dependency);
            if (dependencyItem is null)
                continue;

            var dependencyKey = GetFunctionKey(dependencyItem);

            if (dependency.Direction.Equals("Downstream", StringComparison.OrdinalIgnoreCase))
                edges.Add(new ImpactEdge(currentKey, dependencyKey));
            else if (dependency.Direction.Equals("Upstream", StringComparison.OrdinalIgnoreCase))
                edges.Add(new ImpactEdge(dependencyKey, currentKey));
        }

        return edges
            .GroupBy(x => $"{x.From}|{x.To}", StringComparer.OrdinalIgnoreCase)
            .Select(x => x.First())
            .ToList();
    }

    private static FunctionDependencyInfo? ResolveDependencyFunction(
        IReadOnlyList<FunctionDependencyInfo> functions,
        FunctionDependencyInfo dependency)
    {
        var locationFile = dependency.DependencyLocation;
        var separator = locationFile.IndexOf(':');
        if (separator >= 0)
            locationFile = locationFile[..separator];

        return functions.FirstOrDefault(x =>
            x.Function.Equals(dependency.DependencyFunction, StringComparison.OrdinalIgnoreCase) &&
            (string.IsNullOrWhiteSpace(locationFile) ||
             Path.GetFileName(x.File).Equals(Path.GetFileName(locationFile), StringComparison.OrdinalIgnoreCase)));
    }

    private static void ExpandGraph(
        IReadOnlyList<ImpactEdge> edges,
        IEnumerable<string> seeds,
        HashSet<string> result,
        bool reverse)
    {
        var queue = new Queue<string>(seeds);
        var visited = new HashSet<string>(seeds, StringComparer.OrdinalIgnoreCase);

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            var next = reverse
                ? edges.Where(x => x.To.Equals(current, StringComparison.OrdinalIgnoreCase)).Select(x => x.From)
                : edges.Where(x => x.From.Equals(current, StringComparison.OrdinalIgnoreCase)).Select(x => x.To);

            foreach (var value in next)
            {
                if (!visited.Add(value)) continue;
                result.Add(value);
                queue.Enqueue(value);
            }
        }
    }

    private static string GetFunctionKey(FunctionDependencyInfo value) =>
        $"{value.File}|{value.Function}";

    private static string FormatFunctionKey(string value)
    {
        var separator = value.IndexOf('|');
        if (separator < 0) return value;
        return $"{value[(separator + 1)..]} ({Path.GetFileName(value[..separator])})";
    }

    private static string DescribeFunction(FunctionDependencyInfo value) =>
        $"{value.Function} ({Path.GetFileName(value.File)})";

    private static string FormatDependency(FunctionDependencyInfo dependency) =>
        $"{dependency.DependencyFunction} - {dependency.DependencyLocation} ({dependency.DependencyType})";

    private static string BuildSummary(ChangeImpactResult result)
    {
        var target = string.Join(", ", result.MatchedFunctions);
        var callerText = result.DirectCallers.Count == 0
            ? "no direct callers were detected"
            : $"{result.DirectCallers.Count} direct caller(s)";
        var calleeText = result.DirectCallees.Count == 0
            ? "no direct called functions were detected"
            : $"{result.DirectCallees.Count} direct called function(s)";

        return $"Change target: {target}. Static analysis found {callerText} and {calleeText}. " +
               $"The analysis identifies {result.ImpactedFiles.Count} impacted file(s) across {result.ImpactedProjects.Count} project(s).";
    }

    private static List<string> BuildReviewAreas(ChangeImpactResult result)
    {
        var areas = new List<string>();

        if (result.DirectCallers.Count > 0 || result.TransitiveCallers.Count > 0)
            areas.Add("Review callers and API entry paths before changing the target.");

        if (result.DirectCallees.Count > 0 || result.TransitiveCallees.Count > 0)
            areas.Add("Review called functions and their downstream behavior for regression risk.");

        foreach (var dependency in result.ExternalDependencies)
            areas.Add($"Review the external dependency: {dependency}.");

        if (areas.Count == 0)
            areas.Add("No additional dependency-based review area was detected from the available static evidence.");

        return areas.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private sealed record ImpactEdge(string From, string To);
}

public sealed class ChangeImpactResult
{
    public string Query { get; init; } = "";
    public string Summary { get; set; } = "";
    public List<string> MatchedFunctions { get; init; } = [];
    public List<string> DirectCallers { get; init; } = [];
    public List<string> DirectCallees { get; init; } = [];
    public List<string> TransitiveCallers { get; init; } = [];
    public List<string> TransitiveCallees { get; init; } = [];
    public List<string> ImpactedFiles { get; init; } = [];
    public List<string> ImpactedProjects { get; init; } = [];
    public List<string> ExternalDependencies { get; init; } = [];
    public List<string> RecommendedReviewAreas { get; set; } = [];
}
