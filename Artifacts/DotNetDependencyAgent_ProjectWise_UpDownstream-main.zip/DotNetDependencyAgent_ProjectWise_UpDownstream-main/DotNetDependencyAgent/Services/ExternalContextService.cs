using System.IO;
using System.Text;

namespace DotNetDependencyAgent;

public static class ExternalContextService
{
    private const int MaxTextPerFile = 30000;
    private const int MaxTotalText = 70000;
    private const long MaxBinaryBytes = 12 * 1024 * 1024;

    public static ExternalAnalysisContext Load(IEnumerable<(string Path, string Category)> inputs, string notes)
    {
        var context = new ExternalAnalysisContext { Notes = notes?.Trim() ?? "" };
        var textBudget = MaxTotalText;

        foreach (var input in inputs.DistinctBy(x => x.Path, StringComparer.OrdinalIgnoreCase))
        {
            if (!File.Exists(input.Path)) continue;

            var path = System.IO.Path.GetFullPath(input.Path);
            var info = new FileInfo(path);
            var mime = GetMimeType(path);
            var item = new ExternalContextFileInfo
            {
                FileName = info.Name,
                FilePath = path,
                Category = string.IsNullOrWhiteSpace(input.Category) ? "Architecture / Context" : input.Category,
                MimeType = mime,
                SizeBytes = info.Length
            };

            if (IsTextLike(path, mime))
            {
                try
                {
                    var text = File.ReadAllText(path, Encoding.UTF8);
                    var take = Math.Min(Math.Min(text.Length, MaxTextPerFile), Math.Max(textBudget, 0));
                    item.TextContent = take > 0 ? text[..take] : "";
                    textBudget -= take;
                }
                catch
                {
                    item.TextContent = "[Unable to read this text file.]";
                }
            }
            else if (info.Length <= MaxBinaryBytes)
            {
                try { item.BinaryContent = File.ReadAllBytes(path); } catch { }
            }
            else
            {
                item.TextContent = $"[Binary file omitted because it is larger than {MaxBinaryBytes / (1024 * 1024)} MB.]";
            }

            context.Files.Add(item);
        }

        return context;
    }

    public static string GetMimeType(string path)
    {
        return System.IO.Path.GetExtension(path).ToLowerInvariant() switch
        {
            ".json" => "application/json",
            ".yaml" or ".yml" => "application/yaml",
            ".xml" => "application/xml",
            ".csv" => "text/csv",
            ".txt" => "text/plain",
            ".md" => "text/markdown",
            ".html" or ".htm" => "text/html",
            ".pdf" => "application/pdf",
            ".png" => "image/png",
            ".jpg" or ".jpeg" => "image/jpeg",
            ".gif" => "image/gif",
            ".bmp" => "image/bmp",
            ".webp" => "image/webp",
            _ => "application/octet-stream"
        };
    }

    private static bool IsTextLike(string path, string mime) =>
        mime.StartsWith("text/", StringComparison.OrdinalIgnoreCase) ||
        mime is "application/json" or "application/yaml" or "application/xml";
}
