using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.IO;
using System.Reflection;
using System.Xml.Linq;

namespace DotNetDependencyAgent;

/// <summary>
/// Builds function-to-function dependencies from all C# files in the analyzed solution.
/// Internal calls are resolved to source methods; external calls are resolved to referenced
/// assemblies when their DLL metadata is available.
/// </summary>
public sealed class FunctionDependencyAnalyzer
{
    private static readonly HashSet<string> FrameworkAssemblies = new(StringComparer.OrdinalIgnoreCase)
    {
        "System", "System.Private.CoreLib", "Microsoft.CSharp", "netstandard",
        "System.Runtime", "System.Linq", "System.Collections", "System.Console",
        "System.Threading", "System.Threading.Tasks"
    };

    public static List<FunctionDependencyInfo> Analyze(
        IReadOnlyList<string> sourceFiles,
        IReadOnlyList<ProjectResult> projects,
        IReadOnlyList<PackageInfo> packages,
        CancellationToken cancellationToken = default)
    {
        var files = sourceFiles
            .Where(File.Exists)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .ToList();

        if (files.Count == 0) return [];

        var projectDirectories = projects
            .Select(p => (Project: p.ProjectPath, Directory: Path.GetDirectoryName(p.ProjectPath)!))
            .OrderByDescending(x => x.Directory.Length)
            .ToList();

        var trees = new List<(SyntaxTree Tree, string File, string Project)>();
        foreach (var file in files)
        {
            cancellationToken.ThrowIfCancellationRequested();
            string source;
            try { source = File.ReadAllText(file); }
            catch { continue; }

            var project = projectDirectories.FirstOrDefault(x => IsUnderDirectory(file, x.Directory)).Project ?? "";
            var tree = CSharpSyntaxTree.ParseText(source, path: file, cancellationToken: cancellationToken);
            trees.Add((tree, file, project));
        }

        var dlls = ResolveReferencedDlls(projects, packages);
        var references = BuildMetadataReferences(dlls);
        var compilation = CSharpCompilation.Create(
            "DependencyAnalysis",
            trees.Select(x => x.Tree),
            references,
            new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,
                nullableContextOptions: NullableContextOptions.Enable,
                optimizationLevel: OptimizationLevel.Release));

        var sourceMethods = new Dictionary<IMethodSymbol, FunctionSymbolInfo>(SymbolEqualityComparer.Default);
        var methodsByName = new Dictionary<string, List<FunctionSymbolInfo>>(StringComparer.OrdinalIgnoreCase);
        var result = new List<FunctionDependencyInfo>();

        foreach (var item in trees)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var model = compilation.GetSemanticModel(item.Tree, ignoreAccessibility: true);
            var root = item.Tree.GetRoot(cancellationToken);

            foreach (var method in root.DescendantNodes().OfType<MethodDeclarationSyntax>())
            {
                var symbol = model.GetDeclaredSymbol(method, cancellationToken);
                if (symbol is null) continue;

                var info = CreateSourceFunctionInfo(symbol, item.File, item.Project, method.Identifier.GetLocation().GetLineSpan().StartLinePosition.Line + 1);
                sourceMethods[symbol] = info;
                if (!methodsByName.TryGetValue(info.Name, out var list))
                    methodsByName[info.Name] = list = [];
                list.Add(info);
            }
        }

        foreach (var item in trees)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var model = compilation.GetSemanticModel(item.Tree, ignoreAccessibility: true);

            foreach (var method in item.Tree.GetRoot(cancellationToken).DescendantNodes().OfType<MethodDeclarationSyntax>())
            {
                var callerSymbol = model.GetDeclaredSymbol(method, cancellationToken);
                if (callerSymbol is null || !sourceMethods.TryGetValue(callerSymbol, out var caller)) continue;

                foreach (var invocation in method.DescendantNodes().OfType<InvocationExpressionSyntax>())
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    var symbolInfo = model.GetSymbolInfo(invocation, cancellationToken);
                    var target = symbolInfo.Symbol as IMethodSymbol
                        ?? symbolInfo.CandidateSymbols.OfType<IMethodSymbol>().FirstOrDefault();
                    if (target is null) continue;
                    if (IsCompilerGenerated(target)) continue;

                    if (sourceMethods.TryGetValue(target.OriginalDefinition, out var internalTarget))
                    {
                        AddInternalPair(result, caller, internalTarget, invocation);
                        continue;
                    }

                    if (target.Locations.Any(l => l.IsInSource))
                    {
                        var sourceLocation = target.Locations.FirstOrDefault(l => l.IsInSource);
                        var sourcePath = sourceLocation?.SourceTree?.FilePath ?? "";
                        var sourceMethod = methodsByName.TryGetValue(target.Name, out var candidates)
                            ? candidates.FirstOrDefault(x => x.File.Equals(sourcePath, StringComparison.OrdinalIgnoreCase))
                            : null;
                        if (sourceMethod is not null)
                        {
                            AddInternalPair(result, caller, sourceMethod, invocation);
                            continue;
                        }
                    }

                    var assemblyName = target.ContainingAssembly?.Name ?? "Unknown Assembly";
                    if (FrameworkAssemblies.Contains(assemblyName)) continue;

                    var dllPath = dlls.FirstOrDefault(x => AssemblySimpleName(x).Equals(assemblyName, StringComparison.OrdinalIgnoreCase));
                    var location = string.IsNullOrWhiteSpace(dllPath)
                        ? $"Third-party assembly: {assemblyName}.dll"
                        : $"Third-party DLL: {Path.GetFileName(dllPath)}";
                    var typeName = target.ContainingType?.ToDisplayString(SymbolDisplayFormat.CSharpErrorMessageFormat) ?? "";
                    var externalName = string.IsNullOrWhiteSpace(typeName)
                        ? target.Name
                        : $"{typeName}.{target.Name}()";

                    result.Add(new FunctionDependencyInfo
                    {
                        Function = caller.DisplayName,
                        File = caller.File,
                        Project = caller.ProjectName,
                        Direction = "Downstream",
                        DependencyFunction = externalName,
                        DependencyLocation = location,
                        DependencyType = "Third Party / External",
                        Confidence = dllPath is null ? "Resolved from reference symbol" : "Resolved from DLL metadata",
                        DependencyStatement = $"{caller.DisplayName} depends on {externalName} in {location}",
                        Evidence = invocation.ToString()
                    });
                }
            }
        }

        // Keep every source function visible in the Function Up/Downstream tab, even when
        // no function-level dependency was detected for it. This makes the tab a complete
        // function inventory rather than only a list of methods that happened to call another method.
        var dependencyKeys = result
            .Select(x => $"{x.Function}\u001f{x.File}")
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        foreach (var function in sourceMethods.Values)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var key = $"{function.DisplayName}\u001f{function.File}";
            if (dependencyKeys.Contains(key)) continue;

            result.Add(new FunctionDependencyInfo
            {
                Function = function.DisplayName,
                File = function.File,
                Project = function.ProjectName,
                Direction = "None",
                DependencyFunction = "—",
                DependencyLocation = $"{Path.GetFileName(function.File)}:{function.Line}",
                DependencyType = "Function",
                Confidence = "Resolved from source",
                DependencyStatement = $"{function.DisplayName} has no detected function-level dependencies.",
                Evidence = "Function declaration"
            });
        }

        return result
            .GroupBy(x => $"{x.Function}\u001f{x.File}\u001f{x.Direction}\u001f{x.DependencyFunction}\u001f{x.DependencyLocation}", StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .OrderBy(x => x.File)
            .ThenBy(x => x.Function)
            .ThenBy(x => DirectionOrder(x.Direction))
            .ThenBy(x => x.DependencyFunction)
            .ToList();
    }

    private static void AddInternalPair(List<FunctionDependencyInfo> result, FunctionSymbolInfo caller, FunctionSymbolInfo callee, InvocationExpressionSyntax invocation)
    {
        var location = $"{Path.GetFileName(callee.File)}:{callee.Line}";
        var evidence = invocation.ToString();

        result.Add(new FunctionDependencyInfo
        {
            Function = caller.DisplayName,
            File = caller.File,
            Project = caller.ProjectName,
            Direction = "Downstream",
            DependencyFunction = callee.DisplayName,
            DependencyLocation = location,
            DependencyType = "Internal Function",
            Confidence = "Resolved from source",
            DependencyStatement = $"{caller.DisplayName} depends on {callee.DisplayName} in {Path.GetFileName(callee.File)}",
            Evidence = evidence
        });

        result.Add(new FunctionDependencyInfo
        {
            Function = callee.DisplayName,
            File = callee.File,
            Project = callee.ProjectName,
            Direction = "Upstream",
            DependencyFunction = caller.DisplayName,
            DependencyLocation = $"{Path.GetFileName(caller.File)}:{caller.Line}",
            DependencyType = "Internal Function",
            Confidence = "Resolved from source",
            DependencyStatement = $"{caller.DisplayName} depends on {callee.DisplayName} in {Path.GetFileName(callee.File)}",
            Evidence = evidence
        });
    }

    private static FunctionSymbolInfo CreateSourceFunctionInfo(IMethodSymbol symbol, string file, string project, int line)
    {
        var containingType = symbol.ContainingType?.ToDisplayString(SymbolDisplayFormat.MinimallyQualifiedFormat) ?? "";
        var display = string.IsNullOrWhiteSpace(containingType) ? $"{symbol.Name}()" : $"{containingType}.{symbol.Name}()";
        return new FunctionSymbolInfo(symbol, symbol.Name, display, file, line, ShortProjectName(project));
    }

    private static bool IsCompilerGenerated(IMethodSymbol symbol) =>
        symbol.MethodKind is MethodKind.AnonymousFunction or MethodKind.LocalFunction;

    private static List<string> ResolveReferencedDlls(IReadOnlyList<ProjectResult> projects, IReadOnlyList<PackageInfo> packages)
    {
        var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var project in projects)
        {
            var directory = Path.GetDirectoryName(project.ProjectPath);
            if (directory is null) continue;
            AddDlls(directory, result, maxDepth: 5);
        }

        foreach (var package in packages)
        {
            var packageDirectory = FindNuGetPackageDirectory(package.Name, package.Version);
            if (packageDirectory is not null)
                AddDlls(packageDirectory, result, maxDepth: 6);
        }

        return result.ToList();
    }

    private static string? FindNuGetPackageDirectory(string packageName, string version)
    {
        var roots = new List<string>();
        var env = Environment.GetEnvironmentVariable("NUGET_PACKAGES");
        if (!string.IsNullOrWhiteSpace(env)) roots.Add(env);
        var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        if (!string.IsNullOrWhiteSpace(home)) roots.Add(Path.Combine(home, ".nuget", "packages"));

        foreach (var root in roots.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var path = Path.Combine(root, packageName.ToLowerInvariant(), version);
            if (Directory.Exists(path)) return path;
        }
        return null;
    }

    private static void AddDlls(string root, HashSet<string> output, int maxDepth)
    {
        try
        {
            foreach (var dll in Directory.EnumerateFiles(root, "*.dll", SearchOption.AllDirectories))
            {
                var relative = Path.GetRelativePath(root, dll);
                if (relative.Count(c => c is '/' or '\\') > maxDepth) continue;

                var lower = relative.Replace('\\', '/').ToLowerInvariant();
                // Prefer runtime/build output and target-framework folders. Skip analyzer/tools folders.
                if (lower.Contains("/analyzers/") || lower.Contains("/build/") || lower.Contains("/buildtransitive/")) continue;
                output.Add(Path.GetFullPath(dll));
            }
        }
        catch { }
    }

    private static List<MetadataReference> BuildMetadataReferences(IEnumerable<string> dlls)
    {
        var references = new List<MetadataReference>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        var tpa = (AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") as string ?? "")
            .Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries);
        foreach (var path in tpa)
        {
            if (seen.Add(path))
            {
                try { references.Add(MetadataReference.CreateFromFile(path)); } catch { }
            }
        }

        foreach (var dll in dlls)
        {
            if (!File.Exists(dll) || !seen.Add(dll)) continue;
            try { references.Add(MetadataReference.CreateFromFile(dll)); } catch { }
        }

        return references;
    }

    private static string AssemblySimpleName(string path)
    {
        try { return AssemblyName.GetAssemblyName(path).Name ?? Path.GetFileNameWithoutExtension(path); }
        catch { return Path.GetFileNameWithoutExtension(path); }
    }

    private static bool IsUnderDirectory(string file, string directory)
    {
        var fullFile = Path.GetFullPath(file).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var fullDir = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        return fullFile.StartsWith(fullDir, StringComparison.OrdinalIgnoreCase);
    }

    private static string ShortProjectName(string path) =>
        string.IsNullOrWhiteSpace(path) ? "" : Path.GetFileNameWithoutExtension(path);

    private static int DirectionOrder(string direction) => direction.Equals("Upstream", StringComparison.OrdinalIgnoreCase) ? 0 : 1;

    private sealed record FunctionSymbolInfo(
        IMethodSymbol Symbol,
        string Name,
        string DisplayName,
        string File,
        int Line,
        string ProjectName);
}
