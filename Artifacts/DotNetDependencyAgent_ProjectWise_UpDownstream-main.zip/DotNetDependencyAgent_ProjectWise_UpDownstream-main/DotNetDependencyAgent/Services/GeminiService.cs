using System.IO;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace DotNetDependencyAgent;

public sealed class ChangeTargetResolution
{
    public string Target { get; set; } = "";
    public string Reason { get; set; } = "";
}

public sealed class GeminiService
{
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromMinutes(5) };

    /// <summary>
    /// Resolves a natural-language change request to an exact target already present in the
    /// static dependency report. The model is not allowed to invent a target.
    /// </summary>
    public async Task<string?> ResolveChangeTargetAsync(
        DependencyReport report,
        string changeRequest,
        string apiKey,
        string model,
        CancellationToken ct = default)
    {
        if (report is null)
            throw new ArgumentNullException(nameof(report));

        if (string.IsNullOrWhiteSpace(apiKey))
            return null;

        var request = changeRequest?.Trim() ?? string.Empty;
        if (request.Length == 0)
            return null;

        model = string.IsNullOrWhiteSpace(model) ? "gemini-3.5-flash" : model.Trim();

        var functionCandidates = report.FunctionDependencies
            .GroupBy(x => $"{x.File}|{x.Function}", StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .OrderBy(x => x.File)
            .ThenBy(x => x.Function)
            .Take(1200)
            .Select(x => $"FUNCTION: {x.Function} | FILE: {Path.GetFileName(x.File)} | PROJECT: {ShortName(x.Project)}")
            .ToList();

        var fileCandidates = report.CsFiles
            .Select(Path.GetFileName)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .Take(800)
            .ToList();

        var projectCandidates = report.Projects
            .Select(x => x.ProjectName)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .ToList();

        var dependencyCandidates = report.UniqueDependencySummary
            .Select(x => x.Name)
            .Concat(report.Dependencies.Select(x => x.Name))
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .Take(500)
            .ToList();

        var prompt = $$"""
You are resolving a software change request to an existing target in a .NET repository.

CHANGE REQUEST:
{{request}}

RULES:
1. Select ONLY one exact target from the candidate lists below.
2. Never invent, rename, abbreviate, or paraphrase a target.
3. Prefer a function when the request refers to an API, endpoint, operation, handler, method, upload, chat, process, or similar behavior.
4. Prefer a file when the request clearly refers to a source file.
5. Prefer a project when the request clearly refers to a project/application.
6. Prefer a dependency when the request clearly refers to an external service/library such as Azure Service Bus.
7. Use semantic meaning. For example, "modify Upload API" can map to an existing Upload/UploadFile function if that is the best matching candidate.
8. If no candidate is a reasonable match, return an empty target.
9. Return JSON ONLY.

JSON FORMAT:
{
  "target": "EXACT CANDIDATE TEXT",
  "reason": "short explanation"
}

FUNCTION CANDIDATES:
{{string.Join("\n", functionCandidates)}}

FILE CANDIDATES:
{{string.Join(", ", fileCandidates)}}

PROJECT CANDIDATES:
{{string.Join(", ", projectCandidates)}}

DEPENDENCY CANDIDATES:
{{string.Join(", ", dependencyCandidates)}}
""";

        var body = new
        {
            contents = new[]
            {
                new
                {
                    parts = new[] { new { text = prompt } }
                }
            },
            generationConfig = new
            {
                temperature = 0.0,
                responseMimeType = "application/json"
            }
        };

        var url =
            $"https://generativelanguage.googleapis.com/v1beta/models/{Uri.EscapeDataString(model)}:generateContent?key={Uri.EscapeDataString(apiKey)}";

        using var response = await _http.PostAsJsonAsync(url, body, ct);
        var raw = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Gemini target-resolution request failed ({(int)response.StatusCode}): {raw}");

        var node = JsonNode.Parse(raw);
        var text = node?["candidates"]?[0]?["content"]?["parts"]?[0]?["text"]?.GetValue<string>();
        if (string.IsNullOrWhiteSpace(text))
            return null;

        text = CleanJson(text);

        try
        {
            var result = JsonSerializer.Deserialize<ChangeTargetResolution>(text, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            return result?.Target?.Trim();
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private static string ShortName(string value) =>
        string.IsNullOrWhiteSpace(value) ? "" : Path.GetFileNameWithoutExtension(value);

    public async Task<AiArchitectureReport> AnalyzeAsync(
        DependencyReport report,
        ExternalAnalysisContext externalContext,
        string apiKey,
        string model,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
            throw new InvalidOperationException("Gemini API key is required for AI analysis.");

        model = string.IsNullOrWhiteSpace(model) ? "gemini-3.5-flash" : model.Trim();

        var compact = JsonSerializer.Serialize(
            report,
            new JsonSerializerOptions { WriteIndented = false });

        if (compact.Length > 120000)
            compact = compact[..120000];

        var projectNames = report.Projects
            .Select(x => x.ProjectName)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var projectList = string.Join(", ", projectNames);
        var functionEvidence = BuildFunctionEvidence(report.FunctionDependencies);
        var externalText = BuildExternalTextContext(externalContext);
        var externalManifest = BuildExternalManifest(externalContext);

        var prompt = $$"""
You are a senior .NET software architect performing dependency and change-impact analysis.

IMPORTANT RULES:
1. Use the supplied dependency report, source-derived function evidence, and external context as evidence.
2. Do not invent systems, projects, classes, APIs, databases, queues, callers, or relationships.
3. ProjectReference relationships marked Confirmed are authoritative for source-code project dependencies.
4. Package/source heuristics marked Possible are not facts. Keep their confidence as Possible/Low unless stronger evidence exists.
5. External context is supplementary architecture evidence, not proof of source-code relationships. If it conflicts with static source evidence, explicitly call out the conflict rather than silently choosing one.
6. The repository contains these projects: {{projectList}}
7. Create a repository-level project_architecture using supplied evidence. Show discovered .csproj projects as architecture components and confirmed ProjectReference links as connections. You may include components from external context only when clearly identified there and mark confidence appropriately.
8. Architecture connections must preserve direction. A ProjectReference from A to B means A depends on B.
9. Return one separate project object for every project above.
10. Remove duplicates and keep explanations concise and useful to a .NET developer or engineering manager.
11. If evidence is insufficient, return empty arrays and explain the limitation.
12. Analyze function-level dependencies separately from project-level dependencies. Use the supplied function dependency evidence as the source of truth.
13. Group function analysis by C# file. Include every discovered source function, even if it has no detected dependency. For each function, separately describe callers and called dependencies.
14. For third-party calls, include the actual type and method plus the DLL/assembly location when supplied. Do not invent third-party callers.
15. The function descriptions must be descriptive but concise.
16. Analyze external context separately. Identify useful facts from architecture/context files, API specifications, and sequence diagrams.
17. Use API specifications to identify API endpoints, request/response contracts, and externally visible operations only when the specification actually contains them.
18. Use sequence diagrams to identify call order, participants, and external interactions only when visible in the supplied diagram/document.
19. Add impact considerations that explain what could be affected by a change, but distinguish static evidence from contextual inference.
20. Return JSON ONLY. No Markdown, no code fence, no introductory text.

Return exactly this JSON structure:
{
  "report_title": ".NET Dependency Impact Analysis",
  "executive_summary": "2-5 concise sentences for the repository as a whole.",
  "overall_assessment": "One short repository-level assessment.",
  "project_architecture": {
    "architecture_style": "Evidence-based style such as Layered / Modular / Service-oriented / Unknown",
    "overview": "Concise repository architecture description based only on evidence.",
    "components": [],
    "connections": [],
    "flow_summary": [],
    "notes": []
  },
  "projects": [
    {
      "project_name": "EXACT project name from the dependency report",
      "project_summary": "Short summary for this project only.",
      "upstream_dependencies": [],
      "downstream_dependencies": [],
      "bidirectional_or_possible_dependencies": [],
      "entry_points": [],
      "dependency_flow": [],
      "risks": [],
      "recommendations": [],
      "analysis_notes": []
    }
  ],
  "function_dependency_analysis": [
    {
      "file": "relative/or full C# file path",
      "project": "project name",
      "function": "Type.Method()",
      "upstream_dependencies": ["caller function with file"],
      "downstream_dependencies": ["called function with file or third-party DLL"],
      "description": "descriptive explanation of the function's dependency relationships"
    }
  ],
  "external_context_analysis": {
    "summary": "How the supplied non-source-code context contributes to the analysis.",
    "key_facts": [],
    "api_spec_observations": [],
    "sequence_diagram_observations": [],
    "impact_considerations": [],
    "limitations": []
  },
  "global_recommendations": [],
  "analysis_notes": []
}

EXTERNAL CONTEXT FILE MANIFEST:
{{externalManifest}}

EXTERNAL TEXT CONTEXT:
{{externalText}}

FUNCTION-LEVEL DEPENDENCY EVIDENCE (GROUPED BY FILE):
{{functionEvidence}}

DEPENDENCY REPORT:
{{compact}}
""";

        var parts = new List<object>
        {
            new { text = prompt }
        };

        foreach (var file in externalContext.Files)
        {
            if (file.BinaryContent is { Length: > 0 } bytes &&
                (file.MimeType.StartsWith("image/", StringComparison.OrdinalIgnoreCase) ||
                 file.MimeType == "application/pdf"))
            {
                parts.Add(new
                {
                    inline_data = new
                    {
                        mime_type = file.MimeType,
                        data = Convert.ToBase64String(bytes)
                    }
                });
            }
        }

        var body = new
        {
            contents = new[]
            {
                new
                {
                    parts = parts.ToArray()
                }
            },
            generationConfig = new
            {
                temperature = 0.1,
                responseMimeType = "application/json"
            }
        };

        var url =
            $"https://generativelanguage.googleapis.com/v1beta/models/{Uri.EscapeDataString(model)}:generateContent?key={Uri.EscapeDataString(apiKey)}";

        using var response = await _http.PostAsJsonAsync(url, body, ct);
        var raw = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(
                $"Gemini request failed ({(int)response.StatusCode}): {raw}");
        }

        var node = JsonNode.Parse(raw);

        var text = node?["candidates"]?[0]?["content"]?["parts"]?[0]?["text"]
            ?.GetValue<string>();

        if (string.IsNullOrWhiteSpace(text))
            throw new InvalidOperationException("Gemini returned no analysis content.");

        text = CleanJson(text);

        try
        {
            text = NormalizeStructuredJson(text);

            var result = JsonSerializer.Deserialize<AiArchitectureReport>(
                text,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            if (result is null)
                throw new JsonException("The response deserialized to null.");

            Normalize(result);
            EnsureStaticProjectCoverage(result, report);
            EnsureExternalContextCoverage(result, externalContext);

            return result;
        }
        catch (JsonException ex)
        {
            throw new InvalidOperationException(
                "Gemini returned an invalid structured report. Please run the AI analysis again. " +
                ex.Message,
                ex);
        }
    }

    // Gemini may occasionally return a short text value where the schema expects an object.
    // Example:
    // project_architecture.components: ["Azure Files", "Azure Service Bus"]
    //
    // Normalize those harmless shape variations before strict deserialization.
    private static string NormalizeStructuredJson(string text)
    {
        var root = JsonNode.Parse(text) as JsonObject
            ?? throw new JsonException("Gemini response root is not a JSON object.");

        // Optional external context is truly optional. The AI response is normalized
        // from source-code/static-analysis evidence even when no external files were supplied.
        if (root["project_architecture"] is JsonObject architecture)
        {
            NormalizeObjectArray(
                architecture,
                "components",
                item => item is JsonValue
                    ? new JsonObject
                    {
                        ["name"] = GetNodeString(item),
                        ["type"] = "Component",
                        ["responsibility"] = "AI-identified architecture component.",
                        ["evidence"] = "AI-generated; verify against static evidence.",
                        ["confidence"] = "Possible"
                    }
                    : item);

            NormalizeObjectArray(
                architecture,
                "connections",
                item => item is JsonValue
                    ? new JsonObject
                    {
                        ["from"] = "",
                        ["to"] = "",
                        ["relationship"] = GetNodeString(item),
                        ["confidence"] = "Possible",
                        ["evidence"] = "AI returned a textual connection."
                    }
                    : item);

            EnsureJsonArray(architecture, "flow_summary");
            EnsureJsonArray(architecture, "notes");
        }

        NormalizeObjectArray(
            root,
            "projects",
            item => item is JsonValue
                ? new JsonObject
                {
                    ["project_name"] = GetNodeString(item),
                    ["project_summary"] =
                        "Project identified by the AI; detailed dependencies are taken from static analysis."
                }
                : item);

        if (root["projects"] is JsonArray projects)
        {
            foreach (var node in projects.OfType<JsonObject>())
            {
                NormalizeDependencyArray(node, "upstream_dependencies", "Upstream");
                NormalizeDependencyArray(node, "downstream_dependencies", "Downstream");
                NormalizeDependencyArray(node, "bidirectional_or_possible_dependencies", "Possible");

                NormalizeObjectArray(
                    node,
                    "entry_points",
                    item => item is JsonValue
                        ? new JsonObject
                        {
                            ["component"] = GetNodeString(item),
                            ["entry_type"] = "Unknown",
                            ["trigger"] = "",
                            ["evidence"] = "AI textual entry point",
                            ["confidence"] = "Possible"
                        }
                        : item);

                NormalizeObjectArray(
                    node,
                    "dependency_flow",
                    item => item is JsonValue
                        ? new JsonObject
                        {
                            ["step"] = 0,
                            ["component"] = GetNodeString(item),
                            ["action"] = "",
                            ["direction"] = ""
                        }
                        : item);

                NormalizeObjectArray(
                    node,
                    "risks",
                    item => item is JsonValue
                        ? new JsonObject
                        {
                            ["severity"] = "Unknown",
                            ["area"] = "",
                            ["risk"] = GetNodeString(item),
                            ["recommendation"] = ""
                        }
                        : item);

                NormalizeObjectArray(
                    node,
                    "recommendations",
                    item => item is JsonValue
                        ? new JsonObject
                        {
                            ["priority"] = "Normal",
                            ["recommendation"] = GetNodeString(item),
                            ["benefit"] = ""
                        }
                        : item);

                EnsureJsonArray(node, "analysis_notes");
            }
        }

        NormalizeObjectArray(
            root,
            "function_dependency_analysis",
            item => item is JsonValue
                ? new JsonObject
                {
                    ["file"] = "",
                    ["project"] = "",
                    ["function"] = GetNodeString(item),
                    ["upstream_dependencies"] = new JsonArray(),
                    ["downstream_dependencies"] = new JsonArray(),
                    ["description"] =
                        "Function returned as a textual item by the AI; static function evidence is authoritative."
                }
                : item);

        if (root["function_dependency_analysis"] is JsonArray functions)
        {
            foreach (var function in functions.OfType<JsonObject>())
            {
                NormalizeStringArray(function, "upstream_dependencies");
                NormalizeStringArray(function, "downstream_dependencies");
            }
        }

        NormalizeRecommendationArray(root, "global_recommendations");
        EnsureJsonArray(root, "analysis_notes");

        if (root["external_context_analysis"] is JsonObject external)
        {
            EnsureJsonArray(external, "key_facts");
            EnsureJsonArray(external, "api_spec_observations");
            EnsureJsonArray(external, "sequence_diagram_observations");
            EnsureJsonArray(external, "impact_considerations");
            EnsureJsonArray(external, "limitations");
        }

        return root.ToJsonString();
    }

    private static void NormalizeDependencyArray(
        JsonObject parent,
        string propertyName,
        string direction)
    {
        NormalizeObjectArray(
            parent,
            propertyName,
            item => item is JsonValue
                ? new JsonObject
                {
                    ["name"] = GetNodeString(item),
                    ["type"] = "Unknown",
                    ["direction"] = direction,
                    ["confidence"] = "Possible",
                    ["evidence"] = "AI textual dependency; verify against static evidence.",
                    ["explanation"] = GetNodeString(item)
                }
                : item);
    }

    private static void NormalizeRecommendationArray(
        JsonObject parent,
        string propertyName)
    {
        NormalizeObjectArray(
            parent,
            propertyName,
            item => item is JsonValue
                ? new JsonObject
                {
                    ["priority"] = "Normal",
                    ["recommendation"] = GetNodeString(item),
                    ["benefit"] = ""
                }
                : item);
    }

    private static void NormalizeStringArray(
        JsonObject parent,
        string propertyName)
    {
        if (parent[propertyName] is null)
        {
            parent[propertyName] = new JsonArray();
            return;
        }

        if (parent[propertyName] is JsonArray array)
        {
            var normalized = new JsonArray();

            foreach (var item in array)
            {
                if (item is null)
                    continue;

                if (item is JsonValue)
                {
                    normalized.Add(JsonValue.Create(GetNodeString(item)));
                }
                else if (item is JsonObject obj)
                {
                    // If Gemini returns an object for a string dependency,
                    // retain a useful textual representation rather than failing deserialization.
                    var name = obj["name"]?.ToString()
                               ?? obj["function"]?.ToString()
                               ?? obj["component"]?.ToString()
                               ?? obj.ToJsonString();

                    normalized.Add(JsonValue.Create(name));
                }
            }

            parent[propertyName] = normalized;
            return;
        }

        parent[propertyName] = new JsonArray(JsonValue.Create(GetNodeString(parent[propertyName])));
    }

    private static void EnsureJsonArray(
        JsonObject parent,
        string propertyName)
    {
        if (parent[propertyName] is null)
        {
            parent[propertyName] = new JsonArray();
            return;
        }

        if (parent[propertyName] is JsonArray)
            return;

        // Accept a single string/object as one array item.
        var original = parent[propertyName]!;
        parent[propertyName] = new JsonArray(original.DeepClone());
    }

    private static void NormalizeObjectArray(
        JsonObject parent,
        string propertyName,
        Func<JsonNode, JsonNode> converter)
    {
        if (parent[propertyName] is null)
        {
            parent[propertyName] = new JsonArray();
            return;
        }

        JsonArray source;

        if (parent[propertyName] is JsonArray existingArray)
        {
            source = existingArray;
        }
        else
        {
            source = new JsonArray(parent[propertyName]!.DeepClone());
        }

        var normalized = new JsonArray();

        foreach (var item in source)
        {
            if (item is null)
                continue;

            var converted = converter(item);

            // Always add a clone to the new array. This avoids the
            // "The node already has a parent" exception from JsonNode.
            normalized.Add(converted.DeepClone());
        }

        parent[propertyName] = normalized;
    }

    private static string GetNodeString(JsonNode node)
    {
        if (node is JsonValue value)
        {
            if (value.TryGetValue<string>(out var stringValue))
                return stringValue ?? "";

            return value.ToString();
        }

        return node.ToJsonString();
    }

    private static string BuildExternalManifest(
        ExternalAnalysisContext context)
    {
        if (context.Files.Count == 0)
            return "No external context files were supplied.";

        return string.Join(
            Environment.NewLine,
            context.Files.Select(x =>
                $"- [{x.Category}] {x.FileName} ({x.MimeType}, {x.SizeBytes} bytes)"));
    }

    private static string BuildExternalTextContext(
        ExternalAnalysisContext context)
    {
        var chunks = new List<string>();

        if (!string.IsNullOrWhiteSpace(context.Notes))
        {
            chunks.Add(
                "USER-PROVIDED ARCHITECTURE NOTES:\n" +
                context.Notes.Trim());
        }

        foreach (var file in context.Files.Where(
                     x => !string.IsNullOrWhiteSpace(x.TextContent)))
        {
            chunks.Add(
                $"[{file.Category}] {file.FileName}\n" +
                file.TextContent!.Trim());
        }

        if (chunks.Count == 0)
        {
            return
                "No text-based external context was supplied. " +
                "Binary context, if any, is attached separately.";
        }

        var text = string.Join(
            "\n\n---\n\n",
            chunks);

        return text.Length > 75000
            ? text[..75000]
            : text;
    }

    private static string BuildFunctionEvidence(
        IEnumerable<FunctionDependencyInfo> functions)
    {
        var payload = functions
            .GroupBy(
                x => $"{x.File}|{x.Function}|{x.Project}",
                StringComparer.OrdinalIgnoreCase)
            .OrderBy(g => g.First().File)
            .ThenBy(g => g.First().Function)
            .Select(g => new
            {
                file = g.First().File,
                project = g.First().Project,
                function = g.First().Function,

                upstream = g
                    .Where(x =>
                        x.Direction.Equals(
                            "Upstream",
                            StringComparison.OrdinalIgnoreCase))
                    .Select(x => new
                    {
                        dependency = x.DependencyFunction,
                        location = x.DependencyLocation,
                        type = x.DependencyType,
                        confidence = x.Confidence,
                        evidence = x.Evidence
                    })
                    .ToList(),

                downstream = g
                    .Where(x =>
                        x.Direction.Equals(
                            "Downstream",
                            StringComparison.OrdinalIgnoreCase))
                    .Select(x => new
                    {
                        dependency = x.DependencyFunction,
                        location = x.DependencyLocation,
                        type = x.DependencyType,
                        confidence = x.Confidence,
                        evidence = x.Evidence
                    })
                    .ToList(),

                note = g.Any(x =>
                    x.Direction.Equals(
                        "None",
                        StringComparison.OrdinalIgnoreCase))
                    ? "No detected function-level dependency."
                    : ""
            })
            .ToList();

        var json = JsonSerializer.Serialize(
            payload,
            new JsonSerializerOptions
            {
                WriteIndented = false
            });

        return json.Length > 80000
            ? json[..80000]
            : json;
    }

    private static string CleanJson(string text)
    {
        text = text.Trim();

        if (text.StartsWith("```", StringComparison.Ordinal))
        {
            var firstNewLine = text.IndexOf('\n');

            if (firstNewLine >= 0)
                text = text[(firstNewLine + 1)..];

            var lastFence = text.LastIndexOf(
                "```",
                StringComparison.Ordinal);

            if (lastFence >= 0)
                text = text[..lastFence];
        }

        return text.Trim();
    }

    private static void Normalize(
        AiArchitectureReport report)
    {
        report.ReportTitle = EmptyTo(
            report.ReportTitle,
            ".NET Dependency Impact Analysis");

        report.ExecutiveSummary = EmptyTo(
            report.ExecutiveSummary,
            "No executive summary was returned.");

        report.OverallAssessment = EmptyTo(
            report.OverallAssessment,
            "No overall assessment was returned.");

        report.ProjectArchitecture ??= new AiProjectArchitecture();

        report.ProjectArchitecture.ArchitectureStyle =
            EmptyTo(
                report.ProjectArchitecture.ArchitectureStyle,
                "Unknown");

        report.ProjectArchitecture.Overview =
            EmptyTo(
                report.ProjectArchitecture.Overview,
                "Architecture could not be confidently inferred from the available evidence.");

        report.ProjectArchitecture.Components ??= [];
        report.ProjectArchitecture.Connections ??= [];
        report.ProjectArchitecture.FlowSummary ??= [];
        report.ProjectArchitecture.Notes ??= [];

        report.Projects ??= [];
        report.FunctionDependencyAnalysis ??= [];

        foreach (var function in report.FunctionDependencyAnalysis)
        {
            function.File = function.File?.Trim() ?? "";
            function.Project = function.Project?.Trim() ?? "";
            function.Function = function.Function?.Trim() ?? "";

            function.UpstreamDependencies ??= [];
            function.DownstreamDependencies ??= [];

            function.Description =
                function.Description?.Trim() ?? "";
        }

        report.GlobalRecommendations ??= [];
        report.AnalysisNotes ??= [];

        report.ExternalContextAnalysis ??=
            new AiExternalContextAnalysis();

        report.ExternalContextAnalysis.KeyFacts ??= [];
        report.ExternalContextAnalysis.ApiSpecObservations ??= [];
        report.ExternalContextAnalysis.SequenceDiagramObservations ??= [];
        report.ExternalContextAnalysis.ImpactConsiderations ??= [];
        report.ExternalContextAnalysis.Limitations ??= [];

        foreach (var project in report.Projects)
        {
            project.ProjectName =
                project.ProjectName?.Trim() ?? "";

            project.ProjectSummary =
                project.ProjectSummary?.Trim() ?? "";

            project.UpstreamDependencies ??= [];
            project.DownstreamDependencies ??= [];
            project.BidirectionalOrPossibleDependencies ??= [];
            project.EntryPoints ??= [];
            project.DependencyFlow ??= [];
            project.Risks ??= [];
            project.Recommendations ??= [];
            project.AnalysisNotes ??= [];
        }
    }

    private static void EnsureStaticProjectCoverage(
        AiArchitectureReport ai,
        DependencyReport report)
    {
        EnsureStaticArchitectureCoverage(ai, report);
        EnsureFunctionDependencyCoverage(ai, report);

        foreach (var p in report.Projects)
        {
            var section = ai.Projects.FirstOrDefault(
                x => x.ProjectName.Equals(
                    p.ProjectName,
                    StringComparison.OrdinalIgnoreCase));

            if (section is null)
            {
                section = new AiProjectReport
                {
                    ProjectName = p.ProjectName,
                    ProjectSummary =
                        $"Static dependency summary for {p.ProjectName}."
                };

                ai.Projects.Add(section);
            }

            var confirmed = report.ProjectDependencies
                .Where(x => x.Project.Equals(
                    p.ProjectName,
                    StringComparison.OrdinalIgnoreCase))
                .ToList();

            foreach (var dep in confirmed.Where(
                         x => x.Direction.Equals(
                             "Upstream",
                             StringComparison.OrdinalIgnoreCase)))
            {
                AddStaticDependency(
                    section.UpstreamDependencies,
                    dep.RelatedProject,
                    "Project",
                    "Upstream",
                    dep.Confidence,
                    dep.Relationship,
                    $"{dep.RelatedProject} depends on {p.ProjectName}.");
            }

            foreach (var dep in confirmed.Where(
                         x => x.Direction.Equals(
                             "Downstream",
                             StringComparison.OrdinalIgnoreCase)))
            {
                AddStaticDependency(
                    section.DownstreamDependencies,
                    dep.RelatedProject,
                    "Project",
                    "Downstream",
                    dep.Confidence,
                    dep.Relationship,
                    $"{p.ProjectName} depends on {dep.RelatedProject} through a confirmed ProjectReference.");
            }

            var external = report.UniqueDependencySummary
                .Where(x => x.Project.Equals(
                    p.ProjectName,
                    StringComparison.OrdinalIgnoreCase))
                .ToList();

            foreach (var dep in external)
            {
                var evidence = dep.SourceFiles.Count > 0
                    ? $"{dep.Occurrences} occurrence(s); source: {string.Join(", ", dep.SourceFiles.Take(3))}"
                    : $"{dep.Occurrences} occurrence(s) from package/source heuristic";

                if (dep.Direction.Equals(
                        "Upstream",
                        StringComparison.OrdinalIgnoreCase))
                {
                    AddStaticDependency(
                        section.UpstreamDependencies,
                        dep.Name,
                        dep.Type,
                        "Upstream",
                        dep.Confidence,
                        evidence,
                        $"{dep.Name} appears to depend on {p.ProjectName} based on the available evidence.");
                }
                else if (dep.Direction.Equals(
                             "Downstream",
                             StringComparison.OrdinalIgnoreCase))
                {
                    AddStaticDependency(
                        section.DownstreamDependencies,
                        dep.Name,
                        dep.Type,
                        "Downstream",
                        dep.Confidence,
                        evidence,
                        "Detected as a possible downstream dependency for this project.");
                }
                else
                {
                    AddStaticDependency(
                        section.BidirectionalOrPossibleDependencies,
                        dep.Name,
                        dep.Type,
                        dep.Direction,
                        dep.Confidence,
                        evidence,
                        "Direction is not confirmed from the available static evidence.");
                }
            }

            section.UpstreamDependencies =
                Deduplicate(section.UpstreamDependencies);

            section.DownstreamDependencies =
                Deduplicate(section.DownstreamDependencies);

            section.BidirectionalOrPossibleDependencies =
                Deduplicate(section.BidirectionalOrPossibleDependencies);
        }

        ai.Projects = report.Projects
            .Select(p =>
                ai.Projects.First(
                    x => x.ProjectName.Equals(
                        p.ProjectName,
                        StringComparison.OrdinalIgnoreCase)))
            .ToList();
    }

    private static void EnsureFunctionDependencyCoverage(
        AiArchitectureReport ai,
        DependencyReport report)
    {
        var groups = report.FunctionDependencies
            .GroupBy(
                x => $"{x.File}|{x.Function}|{x.Project}",
                StringComparer.OrdinalIgnoreCase)
            .OrderBy(g => g.First().File)
            .ThenBy(g => g.First().Function)
            .ToList();

        foreach (var group in groups)
        {
            var first = group.First();

            var item = ai.FunctionDependencyAnalysis
                .FirstOrDefault(x =>
                    x.File.Equals(
                        first.File,
                        StringComparison.OrdinalIgnoreCase) &&
                    x.Function.Equals(
                        first.Function,
                        StringComparison.OrdinalIgnoreCase));

            var upstream = group
                .Where(x =>
                    x.Direction.Equals(
                        "Upstream",
                        StringComparison.OrdinalIgnoreCase) &&
                    x.DependencyFunction != "—")
                .Select(x =>
                    $"{x.DependencyFunction} in {x.DependencyLocation}")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            var downstream = group
                .Where(x =>
                    x.Direction.Equals(
                        "Downstream",
                        StringComparison.OrdinalIgnoreCase) &&
                    x.DependencyFunction != "—")
                .Select(x =>
                    $"{x.DependencyFunction} in {x.DependencyLocation}")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (item is null)
            {
                item = new AiFunctionDependencyAnalysis
                {
                    File = first.File,
                    Project = first.Project,
                    Function = first.Function
                };

                ai.FunctionDependencyAnalysis.Add(item);
            }

            foreach (var value in upstream)
            {
                if (!item.UpstreamDependencies.Contains(
                        value,
                        StringComparer.OrdinalIgnoreCase))
                {
                    item.UpstreamDependencies.Add(value);
                }
            }

            foreach (var value in downstream)
            {
                if (!item.DownstreamDependencies.Contains(
                        value,
                        StringComparer.OrdinalIgnoreCase))
                {
                    item.DownstreamDependencies.Add(value);
                }
            }

            if (string.IsNullOrWhiteSpace(item.Description))
            {
                var parts = new List<string>();

                if (downstream.Count > 0)
                {
                    parts.Add(
                        $"{first.Function} depends on {string.Join(", ", downstream)}.");
                }

                if (upstream.Count > 0)
                {
                    parts.Add(
                        $"It is used by {string.Join(", ", upstream)} because those functions call it.");
                }

                if (parts.Count == 0)
                {
                    parts.Add(
                        $"{first.Function} has no detected function-level dependency from the analyzed source and referenced metadata.");
                }

                item.Description = string.Join(" ", parts);
            }
        }

        ai.FunctionDependencyAnalysis = ai.FunctionDependencyAnalysis
            .GroupBy(
                x => $"{x.File}|{x.Function}",
                StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .OrderBy(x => x.File)
            .ThenBy(x => x.Function)
            .ToList();
    }

    private static void EnsureStaticArchitectureCoverage(
        AiArchitectureReport ai,
        DependencyReport report)
    {
        ai.ProjectArchitecture ??= new AiProjectArchitecture();

        ai.ProjectArchitecture.Components ??= [];
        ai.ProjectArchitecture.Connections ??= [];
        ai.ProjectArchitecture.FlowSummary ??= [];
        ai.ProjectArchitecture.Notes ??= [];

        foreach (var p in report.Projects)
        {
            if (!ai.ProjectArchitecture.Components.Any(
                    x => x.Name.Equals(
                        p.ProjectName,
                        StringComparison.OrdinalIgnoreCase)))
            {
                ai.ProjectArchitecture.Components.Add(
                    new AiArchitectureComponent
                    {
                        Name = p.ProjectName,
                        Type = "Project",
                        Responsibility =
                            "Discovered .NET project in the analyzed repository.",
                        Evidence =
                            string.IsNullOrWhiteSpace(p.TargetFramework)
                                ? "Discovered .csproj"
                                : $"Discovered .csproj targeting {p.TargetFramework}",
                        Confidence = "Confirmed"
                    });
            }
        }

        foreach (var dep in report.ProjectDependencies.Where(
                     x => x.Direction.Equals(
                         "Downstream",
                         StringComparison.OrdinalIgnoreCase)))
        {
            if (!ai.ProjectArchitecture.Connections.Any(
                    x =>
                        x.From.Equals(
                            dep.Project,
                            StringComparison.OrdinalIgnoreCase) &&
                        x.To.Equals(
                            dep.RelatedProject,
                            StringComparison.OrdinalIgnoreCase) &&
                        x.Relationship.Equals(
                            "ProjectReference",
                            StringComparison.OrdinalIgnoreCase)))
            {
                ai.ProjectArchitecture.Connections.Add(
                    new AiArchitectureConnection
                    {
                        From = dep.Project,
                        To = dep.RelatedProject,
                        Relationship = "ProjectReference",
                        Confidence = dep.Confidence,
                        Evidence = dep.Relationship
                    });
            }
        }

        ai.ProjectArchitecture.Components =
            ai.ProjectArchitecture.Components
                .GroupBy(
                    x => x.Name,
                    StringComparer.OrdinalIgnoreCase)
                .Select(x => x.First())
                .OrderBy(x => x.Name)
                .ToList();

        ai.ProjectArchitecture.Connections =
            ai.ProjectArchitecture.Connections
                .GroupBy(
                    x => $"{x.From}|{x.To}|{x.Relationship}",
                    StringComparer.OrdinalIgnoreCase)
                .Select(x => x.First())
                .OrderBy(x => x.From)
                .ThenBy(x => x.To)
                .ToList();
    }

    private static void EnsureExternalContextCoverage(
        AiArchitectureReport ai,
        ExternalAnalysisContext context)
    {
        ai.ExternalContextAnalysis ??=
            new AiExternalContextAnalysis();

        ai.ExternalContextAnalysis.KeyFacts ??= [];
        ai.ExternalContextAnalysis.ApiSpecObservations ??= [];
        ai.ExternalContextAnalysis.SequenceDiagramObservations ??= [];
        ai.ExternalContextAnalysis.ImpactConsiderations ??= [];
        ai.ExternalContextAnalysis.Limitations ??= [];

        if (context.Files.Count == 0 &&
            string.IsNullOrWhiteSpace(context.Notes))
        {
            ai.ExternalContextAnalysis.Summary =
                "No external architecture, API, or sequence-diagram context was supplied for this run.";

            return;
        }

        if (string.IsNullOrWhiteSpace(
                ai.ExternalContextAnalysis.Summary))
        {
            ai.ExternalContextAnalysis.Summary =
                $"The analysis included {context.Files.Count} external context file(s) in addition to source-code evidence.";
        }

        foreach (var file in context.Files)
        {
            var marker = $"{file.Category}: {file.FileName}";

            var target =
                file.Category.Equals(
                    "API Specification",
                    StringComparison.OrdinalIgnoreCase)
                    ? ai.ExternalContextAnalysis.ApiSpecObservations
                    : file.Category.Equals(
                        "Sequence Diagram",
                        StringComparison.OrdinalIgnoreCase)
                        ? ai.ExternalContextAnalysis.SequenceDiagramObservations
                        : ai.ExternalContextAnalysis.KeyFacts;

            if (!target.Any(
                    x => x.Contains(
                        file.FileName,
                        StringComparison.OrdinalIgnoreCase)))
            {
                target.Add(
                    $"Supplied external input: {marker}.");
            }
        }
    }

    private static void AddStaticDependency(
        List<AiDependencyItem> items,
        string name,
        string type,
        string direction,
        string confidence,
        string evidence,
        string explanation)
    {
        if (items.Any(
                x =>
                    x.Name.Equals(
                        name,
                        StringComparison.OrdinalIgnoreCase) &&
                    x.Direction.Equals(
                        direction,
                        StringComparison.OrdinalIgnoreCase)))
        {
            return;
        }

        items.Add(
            new AiDependencyItem
            {
                Name = name,
                Type = type,
                Direction = direction,
                Confidence = confidence,
                Evidence = evidence,
                Explanation = explanation
            });
    }

    private static List<AiDependencyItem> Deduplicate(
        IEnumerable<AiDependencyItem> items) =>
        items
            .GroupBy(
                x => $"{x.Name}|{x.Direction}|{x.Type}",
                StringComparer.OrdinalIgnoreCase)
            .Select(g =>
                g.OrderBy(
                    x => ConfidenceOrder(x.Confidence))
                    .First())
            .OrderBy(x => x.Type)
            .ThenBy(x => x.Name)
            .ToList();

    private static int ConfidenceOrder(
        string? confidence) =>
        confidence?.ToLowerInvariant() switch
        {
            "confirmed" => 0,
            "high" => 1,
            "possible" => 2,
            "low" => 3,
            _ => 4
        };

    private static string EmptyTo(
        string? value,
        string fallback) =>
        string.IsNullOrWhiteSpace(value)
            ? fallback
            : value.Trim();
}